﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void CheckAndPerformDailyReset()
        {
            // 기존 방식은 09:00에 LoadSymbolDataAsync()를 다시 호출했지만,
            // 현재 창이 같은 종목을 보고 있으면 FocusOpenedSymbolWindow()에서 즉시 반환되어
            // 실제 차트 초기화가 되지 않을 수 있었다.
            //
            // 실제 장 시작 초기화는 ResetChartForNewTradingDayIfNeeded(tick)에서
            // "전일 데이터 → 오늘 첫 실시간틱" 날짜 전환을 기준으로 처리한다.
            DateTime now = DateTime.Now;

            if (now.Hour == 0 && _isDailyResetDone)
                _isDailyResetDone = false;
        }
        

        private async Task ReloadCurrentSymbolForNewTradingDayAsync(TrackedSymbol tick)
        {
            if (tick == null || string.IsNullOrWhiteSpace(tick.Code))
                return;

            string code = tick.Code;
            string name = Context != null && Context.Code == code
                ? Context.Name
                : string.Empty;

            var holding = AccountHoldings?.FirstOrDefault(h => h.Code == code);
            if (holding != null)
            {
                name = string.IsNullOrWhiteSpace(holding.Name) ? name : holding.Name;
                //ClearHoldingStoreForReload(holding);
            }

            var symbol = new Symbol
            {
                Code = code,
                Name = name,
                LastPrice = tick.LastPrice > 0 ? tick.LastPrice.ToString() : Context?.LastPrice.ToString()
            };

            await LoadSymbolDataForCurrentWindowAsync(symbol, waitHoldingLoad: false);
        }
        

        private bool ResetChartForNewTradingDayIfNeeded(TrackedSymbol tick)
        {
            if (tick == null || tick.LastUpdated == default(DateTime))
                return false;

            if (string.IsNullOrWhiteSpace(Context.Code) || Context.Code != tick.Code)
                return false;

            DateTime tickDate = tick.LastUpdated.Date;
            DateTime currentDataDate = DateTime.MinValue;

            lock (_syncLock)
            {
                if (_minuteHistoryBuffer.Count > 0)
                    currentDataDate = _minuteHistoryBuffer[_minuteHistoryBuffer.Count - 1].CandleTime.Date;
                else if (Context.SymbolList != null && Context.SymbolList.Count > 0)
                    currentDataDate = Context.SymbolList[Context.SymbolList.Count - 1].LastUpdated.Date;
            }

            if (currentDataDate == DateTime.MinValue || currentDataDate >= tickDate)
                return false;

            if (_isDailyResetDone)
                return false;

            _isDailyResetDone = true;

            lock (_syncLock)
            {
                // 핵심 수정:
                // 전체 Clear 금지.
                // 오늘 데이터가 있으면 유지하고, 전일 데이터만 제거.
                _minuteHistoryBuffer.RemoveAll(x => x.CandleTime.Date < tickDate);

                _minuteTickBuffer.Clear();
                _currentMinute = DateTime.MinValue;
                _lastChartMinute = DateTime.MinValue;

                // Context.SymbolList도 전체 Clear 후 끝내면 차트가 실시간만 남을 수 있음.
                // 오늘 데이터만 다시 채운다.
                var analysisData = _minuteHistoryBuffer
                    .Select(ToTrackedSymbol)
                    .ToList();

                Context.SymbolList.Clear();
                Context.SymbolList.AddRange(analysisData);
            }

            lock (_realTimeBuffer)
            {
                // 기존 실시간 버퍼 전체 삭제는 유지해도 되지만,
                // 현재 틱은 반드시 보관.
                _realTimeBuffer.Clear();
                _realTimeBuffer.Enqueue(tick);
            }

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Send,
                new Action(() =>
                {
                    OnChartResetRequired?.Invoke();

                    Context.LastPrice = tick.LastPrice;
                    Context.Strength = tick.Strength;
                    IsLoading = false;

                    AddLog($"🧹 장 시작 차트 경계 초기화: {tick.Code} / {currentDataDate:yyyy-MM-dd} → {tickDate:yyyy-MM-dd}");
                }));

            return false;
        }
        

        private bool ResetHoldingChartForNewTradingDayIfNeeded(HoldingSymbolContext store, TrackedSymbol tick)
        {
            if (store == null || tick == null || tick.LastUpdated == default(DateTime))
                return false;

            if (string.IsNullOrWhiteSpace(Context.Code) || Context.Code != tick.Code)
                return false;

            DateTime tickDate = tick.LastUpdated.Date;
            DateTime currentDataDate = DateTime.MinValue;

            lock (store.SyncRoot)
            {
                if (store.MinuteList.Count > 0)
                    currentDataDate = store.MinuteList[store.MinuteList.Count - 1].LastUpdated.Date;
                else if (store.SymbolList.Count > 0)
                    currentDataDate = store.SymbolList[store.SymbolList.Count - 1].LastUpdated.Date;
            }

            if (currentDataDate == DateTime.MinValue || currentDataDate >= tickDate)
                return false;

            if (_isDailyResetDone)
                return false;

            _isDailyResetDone = true;

            lock (_syncLock)
            {
                _minuteTickBuffer.Clear();
                _currentMinute = DateTime.MinValue;
                _lastChartMinute = DateTime.MinValue;
            }

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Send,
                new Action(() =>
                {
                    OnChartResetRequired?.Invoke();

                    Context.LastPrice = tick.LastPrice;
                    Context.Strength = tick.Strength;
                    IsLoading = false;

                    AddLog($"🧹 보유주 장 시작 차트 초기화 1회: {tick.Code} / {currentDataDate:yyyy-MM-dd} → {tickDate:yyyy-MM-dd}");
                }));

            // 중요:
            // true 반환하면 현재 틱이 아래 UpsertHoldingMinuteCandle_NoSort()로 못 내려감.
            // 그래서 false 반환해야 함.
            return false;
        }
        
    }
}
