﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void AddRecentRealtimeTick(TrackedSymbol tick)
        {
            if (tick == null || string.IsNullOrWhiteSpace(tick.Code))
                return;

            lock (_recentRealtimeTickLock)
            {
                _recentRealtimeTicks.Enqueue(CloneTrackedSymbolForAutoTrade(tick));
                TrimRecentRawTicks_NoLock(_recentRealtimeTicks, tick.LastUpdated);

                AddOrMergeTickFrame_NoLock(_recentTickFrames, tick);
                TrimTickFrames_NoLock(_recentTickFrames, tick.LastUpdated);
            }
        }
        

        private void TrimRecentRawTicks_NoLock(Queue<TrackedSymbol> queue, DateTime now)
        {
            if (queue == null || queue.Count == 0)
                return;

            DateTime cutoff = now.AddSeconds(-RawRealtimeTickRetentionSeconds);

            while (queue.Count > 0 && queue.Peek().LastUpdated < cutoff)
                queue.Dequeue();
        }

        

        private void MergeRecentRawTicks_NoLock(Queue<TrackedSymbol> queue, IEnumerable<TrackedSymbol> ticks, string code)
        {
            if (queue == null || ticks == null)
                return;

            var merged = queue
                .Concat(ticks.Where(x => x != null && x.Code == code))
                .Where(x => x != null && x.LastUpdated != default(DateTime))
                .OrderBy(x => x.LastUpdated)
                .GroupBy(x => new
                {
                    x.Code,
                    x.LastUpdated,
                    x.LastPrice,
                    x.LastVolume
                })
                .Select(g => g.Last())
                .ToList();

            if (merged.Count == 0)
                return;

            DateTime latest = merged[merged.Count - 1].LastUpdated;
            DateTime cutoff = latest.AddSeconds(-RawRealtimeTickRetentionSeconds);

            queue.Clear();

            foreach (var tick in merged.Where(x => x.LastUpdated >= cutoff))
                queue.Enqueue(CloneTrackedSymbolForAutoTrade(tick));
        }
        

        private void AddOrMergeTickFrame_NoLock(List<TickFrame> frames, TrackedSymbol tick)
        {
            if (frames == null || tick == null || string.IsNullOrWhiteSpace(tick.Code))
                return;

            DateTime sec = new DateTime(
                tick.LastUpdated.Year,
                tick.LastUpdated.Month,
                tick.LastUpdated.Day,
                tick.LastUpdated.Hour,
                tick.LastUpdated.Minute,
                tick.LastUpdated.Second);

            TickFrame frame = frames.Count == 0
                ? null
                : frames[frames.Count - 1];

            if (frame == null || frame.Code != tick.Code || frame.Time != sec)
            {
                frames.Add(new TickFrame
                {
                    Code = tick.Code,
                    Time = sec,
                    Open = tick.LastPrice,
                    High = tick.LastPrice,
                    Low = tick.LastPrice,
                    Close = tick.LastPrice,
                    Volume = (long)Math.Abs(tick.LastVolume),
                    AccumulatedVolume = tick.AccumulatedVolume,
                    AvgStrength = tick.Strength,
                    LastStrength = tick.Strength,
                    TotalAskQty = tick.TotalAskQty,
                    TotalBidQty = tick.TotalBidQty,
                    TickCount = 1,
                    BuyTickCount = tick.Side == "B" ? 1 : 0,
                    SellTickCount = tick.Side == "S" ? 1 : 0,
                    UpdatedAt = tick.LastUpdated
                });

                return;
            }

            frame.High = Math.Max(frame.High, tick.LastPrice);
            frame.Low = frame.Low <= 0 ? tick.LastPrice : Math.Min(frame.Low, tick.LastPrice);
            frame.Close = tick.LastPrice;
            frame.Volume += (long)Math.Abs(tick.LastVolume);
            frame.AccumulatedVolume = Math.Max(frame.AccumulatedVolume, tick.AccumulatedVolume);

            frame.AvgStrength =
                ((frame.AvgStrength * frame.TickCount) + tick.Strength) /
                Math.Max(1, frame.TickCount + 1);

            frame.LastStrength = tick.Strength;
            frame.TotalAskQty = tick.TotalAskQty > 0 ? tick.TotalAskQty : frame.TotalAskQty;
            frame.TotalBidQty = tick.TotalBidQty > 0 ? tick.TotalBidQty : frame.TotalBidQty;
            frame.TickCount++;

            if (tick.Side == "B")
                frame.BuyTickCount++;
            else if (tick.Side == "S")
                frame.SellTickCount++;

            frame.UpdatedAt = tick.LastUpdated;
        }
        

        private void TrimTickFrames_NoLock(List<TickFrame> frames, DateTime now)
        {
            if (frames == null || frames.Count == 0)
                return;

            DateTime cutoff = now.AddMinutes(-TickFrameRetentionMinutes);
            frames.RemoveAll(x => x == null || x.Time < cutoff);
        }
        

        private void ResetRealtimeTickWindow()
        {
            lock (_recentRealtimeTickLock)
            {
                _recentRealtimeTicks.Clear();
                _recentTickFrames.Clear();
            }
        }
        

        private void Kiwoom_OnTickReceived(string windowId, TrackedSymbol tick)
        {
            if (!IsCurrentWindowTick(windowId, tick))
                return;

            if (ResetChartForNewTradingDayIfNeeded(tick))
                return;

            AddRecentRealtimeTick(tick);

            if (!_isHistoryBindingComplete)
            {
                BufferRealtimeTick(tick);
                UpdateCurrentSymbolFromTick(tick, isLoading: true);
                return;
            }

            DateTime tickMinute = ToMinuteTime(tick.LastUpdated);
            bool shouldRefreshChart = GetMaxMinuteTimeFromCurrentBuffer() < tickMinute;

            UpsertCurrentMinuteCandle_NoSort(tick);
            CheckAndPerformDailyReset();

            TrackedSymbol latestMinute = null;

            if (shouldRefreshChart)
            {
                lock (_syncLock)
                {
                    latestMinute = GetLatestCurrentMinuteForChart_NoLock();
                }
            }

            UpdateCurrentSymbolFromTick(tick, isLoading: false);
            UpdateAccountHoldingPrice(tick.Code, tick.LastPrice);

            if (shouldRefreshChart && latestMinute != null)
            {
                RequestRealtimeMinuteChartRefresh(latestMinute);
                SyncAutoTradeMinuteCandles(tick.Code, "일반 실시간 분봉 갱신");
            }

            TryEnqueueAutoTradeTick(tick);
        }

        private void TryEnqueueAutoTradeTick(TrackedSymbol tick)
        {
            if (tick == null)
                return;

            if (_autoTradeSettings == null || !_autoTradeSettings.Enabled)
                return;

            if (_autoTradeController == null)
                return;

            if (!CanRunAutoTradeForTick(tick))
                return;

            DateTime now = DateTime.Now;

            if ((now - _lastAutoTradeEnqueueTime).TotalMilliseconds < AutoTradeTickEnqueueIntervalMs)
                return;

            _lastAutoTradeEnqueueTime = now;

            HogaData latestHoga = null;

            lock (_latestHogaLock)
            {
                if (_latestHogaForAutoTrade != null &&
                    _latestHogaForAutoTrade.Code == tick.Code)
                {
                    latestHoga = _latestHogaForAutoTrade;
                }
            }

            if (latestHoga != null)
                _autoTradeController.UpdateHoga(latestHoga);

            _autoTradeController.EnqueueLatestTick(CloneTrackedSymbolForAutoTrade(tick));
        }

        private void Kiwoom_OnRecentTicksReceived(string windowId, string code, List<TrackedSymbol> ticks, bool isLast)
        {
            if (!string.IsNullOrWhiteSpace(windowId) && windowId.StartsWith("INVTICK:"))
            {
                HandleHoldingRecentTicks(windowId, code, ticks, isLast);
                return;
            }

            if (Context == null || windowId != this.WindowId || code != Context.Code)
                return;

            if (ticks != null && ticks.Count > 0)
            {
                var ordered = GetOrderedValidTicks(ticks, code);

                lock (_recentRealtimeTickLock)
                {
                    MergeRecentRawTicks_NoLock(_recentRealtimeTicks, ordered, code);

                    foreach (var tick in ordered)
                        AddOrMergeTickFrame_NoLock(_recentTickFrames, tick);

                    DateTime latest = GetLatestTickTimeOrNow(ordered);

                    TrimTickFrames_NoLock(_recentTickFrames, latest);
                    TrimRecentRawTicks_NoLock(_recentRealtimeTicks, latest);
                }
            }

            if (!isLast)
                return;

            int rawCount;
            int frameCount;

            lock (_recentRealtimeTickLock)
            {
                rawCount = _recentRealtimeTicks.Count;
                frameCount = _recentTickFrames.Count;
            }

            AddLog($"✅ 최근틱 보강 완료: {code} / 원본30초={rawCount}개 / 초봉5분={frameCount}개");

            SeedAutoTradeHistory(code);
        }

        private void SeedAutoTradeHistory(string code)
        {
            if (string.IsNullOrWhiteSpace(code) || _autoTradeController == null)
                return;

            var minutes = GetMinuteCandlesForAutoTrade(code)
                .Where(x => x != null)
                .OrderBy(x => x.LastUpdated)
                .Select(CloneTrackedSymbolForAutoTrade)
                .ToList();

            if (minutes.Count > 0)
                _autoTradeController.UpdateMinuteCandles(code, minutes);

            List<TrackedSymbol> rawTicks30s = new List<TrackedSymbol>();
            List<TickFrame> tickFrames5m = new List<TickFrame>();

            HoldingSymbolContext store;
            if (GlobalHoldingStore.TryGet(code, out store) && store != null)
            {
                lock (store.SyncRoot)
                {
                    rawTicks30s = store.RecentTickList
                        .Where(x => x != null && x.Code == code)
                        .OrderBy(x => x.LastUpdated)
                        .Select(CloneTrackedSymbolForAutoTrade)
                        .ToList();

                    tickFrames5m = store.TickFrameList
                        .Where(x => x != null && x.Code == code)
                        .OrderBy(x => x.Time)
                        .Select(CloneTickFrame)
                        .ToList();
                }
            }

            if (rawTicks30s.Count == 0 || tickFrames5m.Count == 0)
            {
                lock (_recentRealtimeTickLock)
                {
                    if (rawTicks30s.Count == 0)
                    {
                        rawTicks30s = _recentRealtimeTicks
                            .Where(x => x != null && x.Code == code)
                            .OrderBy(x => x.LastUpdated)
                            .Select(CloneTrackedSymbolForAutoTrade)
                            .ToList();
                    }

                    if (tickFrames5m.Count == 0)
                    {
                        tickFrames5m = _recentTickFrames
                            .Where(x => x != null && x.Code == code)
                            .OrderBy(x => x.Time)
                            .Select(CloneTickFrame)
                            .ToList();
                    }
                }
            }

            if (rawTicks30s.Count > 0)
                _autoTradeController.SeedRecentTicks(rawTicks30s);

            if (tickFrames5m.Count > 0)
                _autoTradeController.SeedTickFrames(code, tickFrames5m);

            //_autoTradeController.UpdateCash(CurrentBalance);
            //_autoTradeController.UpdateOpenOrders(GetOpenOrdersForAutoTrade());
            SyncAutoTradeState("분석 데이터 Seed");

            if (Context != null && Context.Code == code)
            {
                _autoTradeController.UpdatePosition(
                    code,
                    GetHoldingQtyByCode(code),
                    GetHoldingEntryPriceByCode(code));
            }

            if (minutes.Count >= 3)
            {
                MarkAutoTradeDataReady(code);

                AddAutoTradeAnalysisLog(
                    $"[자동매매] 분석 데이터 준비 완료: {code} / " +
                    $"분봉={minutes.Count}, 원본30초={rawTicks30s.Count}, 초봉5분={tickFrames5m.Count}");
            }
            else
            {
                MarkAutoTradeDataNotReady(code);

                AddAutoTradeAnalysisLog(
                    $"[자동매매] 분석 데이터 부족: {code} / " +
                    $"분봉={minutes.Count}, 원본30초={rawTicks30s.Count}, 초봉5분={tickFrames5m.Count}");
            }
        }


        private void HandleHoldingRecentTicks(string windowId, string code, List<TrackedSymbol> ticks, bool isLast)
        {
            if (string.IsNullOrWhiteSpace(code))
                code = windowId.Replace("INVTICK:", "");

            var store = GlobalHoldingStore.GetOrCreate(code);

            if (ticks != null && ticks.Count > 0)
            {
                var ordered = GetOrderedValidTicks(ticks, code);

                lock (store.SyncRoot)
                {
                    foreach (var tick in ordered)
                        AddRecentTickToHoldingStore_NoLock(store, tick);

                    if (ordered.Count > 0)
                        store.LastTickTime = ordered[ordered.Count - 1].LastUpdated;

                    TrimHoldingRecentTicks_NoLock(store);
                }
            }

            if (!isLast)
                return;

            int rawCount;
            int frameCount;

            lock (store.SyncRoot)
            {
                store.IsRecentTickLoaded = true;

                if (store.RecentTickList.Count > 0)
                    store.LastTickTime = store.RecentTickList[store.RecentTickList.Count - 1].LastUpdated;

                TrimHoldingRecentTicks_NoLock(store);
                RecalculateHoldingLoadState(store);

                rawCount = store.RecentTickList.Count;
                frameCount = store.TickFrameList.Count;
            }

            Application.Current.Dispatcher.BeginInvoke(
                DispatcherPriority.DataBind,
                new Action(() =>
                {
                    var holding = AccountHoldings.FirstOrDefault(x => x.Code == code);
                    if (holding != null)
                    {
                        holding.IsHistoryLoading = !store.IsHistoryLoaded;
                        holding.IsHistoryLoaded = store.IsHistoryLoaded;
                    }
                }));

            AddLog($"✅ 보유주 최근틱 로딩 완료: {code} / 원본30초={rawCount}개 / 초봉5분={frameCount}개");
        }
        

        private List<TrackedSymbol> AggregateToMinuteBars(List<TrackedSymbol> source)
        {
            var result = new List<TrackedSymbol>();

            if (source == null || source.Count == 0)
                return result;

            DateTime currentMinute = DateTime.MinValue;
            List<TrackedSymbol> buffer = new List<TrackedSymbol>();

            foreach (var tick in source)
            {
                if (tick == null)
                    continue;

                DateTime minute = ToMinuteTime(tick.LastUpdated);

                if (currentMinute == DateTime.MinValue)
                    currentMinute = minute;

                if (minute != currentMinute)
                {
                    var merged = MergeMinuteTicksCore(buffer, currentMinute);
                    if (merged != null)
                        result.Add(merged);

                    buffer.Clear();
                    currentMinute = minute;
                }

                buffer.Add(tick);
            }

            if (buffer.Count > 0)
            {
                var merged = MergeMinuteTicksCore(buffer, currentMinute);
                if (merged != null)
                    result.Add(merged);
            }

            return result;
        }
        

        private TrackedSymbol MergeMinuteTicksCore(List<TrackedSymbol> ticks, DateTime minute)
        {
            if (ticks == null || ticks.Count == 0)
                return null;

            var first = ticks[0];
            var last = ticks[ticks.Count - 1];

            double totalVolume = 0;
            double strengthWeightSum = 0;
            double high = double.MinValue;
            double low = double.MaxValue;

            foreach (var tick in ticks)
            {
                double vol = Math.Abs(tick.LastVolume);

                totalVolume += vol;
                strengthWeightSum += tick.Strength * vol;

                if (tick.LastPrice > high)
                    high = tick.LastPrice;

                if (tick.LastPrice < low)
                    low = tick.LastPrice;
            }

            if (totalVolume <= 0)
                totalVolume = 1;

            return new TrackedSymbol
            {
                Code = first.Code,
                LastUpdated = minute,

                LastPrice = last.LastPrice,
                ClosePrice = last.LastPrice,
                HighPrice = high,
                LowPrice = low,

                LastVolume = totalVolume,
                AccumulatedVolume = last.AccumulatedVolume,
                Strength = strengthWeightSum / totalVolume,

                TotalAskQty = last.TotalAskQty,
                TotalBidQty = last.TotalBidQty,
                Side = last.Side
            };
        }
        

        private void AddTickToBuffer(TrackedSymbol tick)
        {
            lock (_syncLock)
            {
                Context.SymbolList.Add(tick);
                Context.Code = tick.Code;
                Context.LastPrice = tick.LastPrice;

                if (Context.CurrentHold != null)
                {
                    Context.CurrentHold.CurrentPrice = tick.LastPrice;
                }
            }
        }
    
    }
}
