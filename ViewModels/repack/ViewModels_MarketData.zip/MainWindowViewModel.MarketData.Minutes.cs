﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private List<TrackedSymbol> GetChartMinuteData(List<TrackedSymbol> source)
        {
            if (source == null || source.Count == 0)
                return new List<TrackedSymbol>();

            // source는 과거분봉 완료 시점에 1회 정렬되고,
            // 실시간 분봉은 Upsert에서 시간 위치를 보정해서 유지한다.
            // 여기서는 매번 OrderBy 하지 않는다.
            DateTime lastDate = source[source.Count - 1].LastUpdated.Date;

            return source
                .Where(x => x != null && x.LastUpdated.Date == lastDate)
                .ToList();
        }
        

        private void UpsertCurrentMinuteCandle_NoSort(TrackedSymbol tick)
        {
            var incoming = ToRealtimeMinuteCandle(tick);
            if (incoming == null)
                return;

            lock (_syncLock)
            {
                UpsertMinuteCandle_NoSort(_minuteHistoryBuffer, incoming, preferRealtime: true);
            }
        }
        

        private void UpsertHoldingMinuteCandle_NoSort(HoldingSymbolContext store, TrackedSymbol tick)
        {
            if (store == null || tick == null)
                return;

            var incoming = ToRealtimeMinuteSymbol(tick);
            UpsertTrackedMinute_NoSort(store.MinuteList, incoming, preferRealtime: true);
        }
        

        private void UpsertMinuteCandle_NoSort(List<MinuteCandleRecord> list, MinuteCandleRecord incoming, bool preferRealtime)
        {
            if (list == null || incoming == null)
                return;

            // 일반적인 실시간 흐름: 마지막 분봉과 같은 시간이면 병합, 이후 시간이면 바로 추가.
            // 이 경로가 대부분이므로 정렬은 하지 않는다.
            if (list.Count == 0)
            {
                list.Add(incoming);
                return;
            }

            var last = list[list.Count - 1];

            if (last.Code == incoming.Code &&
                last.Interval == incoming.Interval &&
                last.CandleTime == incoming.CandleTime)
            {
                MergeMinuteCandle(last, incoming, preferRealtime);
                return;
            }

            if (incoming.CandleTime > last.CandleTime)
            {
                list.Add(incoming);
                return;
            }

            // 과거분봉/버퍼 병합 중 앞뒤가 섞여 들어오는 경우만 위치 보정.
            // 매번 전체 정렬하지 않고, 뒤에서 앞으로 필요한 위치만 찾는다.
            for (int i = list.Count - 2; i >= 0; i--)
            {
                var old = list[i];

                if (old.Code == incoming.Code &&
                    old.Interval == incoming.Interval &&
                    old.CandleTime == incoming.CandleTime)
                {
                    MergeMinuteCandle(old, incoming, preferRealtime);
                    return;
                }

                if (old.CandleTime < incoming.CandleTime)
                {
                    list.Insert(i + 1, incoming);
                    return;
                }
            }

            list.Insert(0, incoming);
        }
        

        private void MergeMinuteCandle(MinuteCandleRecord old, MinuteCandleRecord incoming, bool preferRealtime)
        {
            if (old == null || incoming == null)
                return;

            bool oldIsReal = IsRealMinuteSource(old.Source);
            bool incomingIsReal = IsRealMinuteSource(incoming.Source);

            // Open은 기존 분봉의 시작가 유지. 기존값이 없을 때만 보정.
            if (old.Open <= 0)
                old.Open = incoming.Open;

            old.High = Math.Max(old.High, incoming.High);
            old.Low = old.Low <= 0 ? incoming.Low : Math.Min(old.Low, incoming.Low);

            if (preferRealtime && oldIsReal && !incomingIsReal)
            {
                // 이미 실시간 분봉이 있는 상태에서 늦게 도착한 HIST는 종가를 덮지 않음.
            }
            else
            {
                old.Close = incoming.Close;
            }

            // 같은 분의 HIST와 REAL을 단순 합산하면 중복 거래량이 될 수 있어 큰 값을 유지.
            // REAL끼리 들어오는 경우는 incoming 자체가 단일 틱 기반이므로 기존 로직처럼 누적.
            if (oldIsReal && incomingIsReal)
                old.Volume += incoming.Volume;
            else
                old.Volume = Math.Max(old.Volume, incoming.Volume);

            old.AccumulatedVolume = Math.Max(old.AccumulatedVolume, incoming.AccumulatedVolume);
            old.Strength = incoming.Strength > 0 ? incoming.Strength : old.Strength;
            old.TotalAskQty = incoming.TotalAskQty > 0 ? incoming.TotalAskQty : old.TotalAskQty;
            old.TotalBidQty = incoming.TotalBidQty > 0 ? incoming.TotalBidQty : old.TotalBidQty;
            old.Source = MergeMinuteSource(old.Source, incoming.Source);
            old.CreatedAt = DateTime.Now;
        }
        

        private bool IsRealMinuteSource(string source)
        {
            return source == "REAL" || source == "REAL_MIN" || source == "HIST+REAL";
        }
        

        private string MergeMinuteSource(string oldSource, string incomingSource)
        {
            bool hasHist = oldSource == "HIST" || incomingSource == "HIST" || oldSource == "HIST+REAL" || incomingSource == "HIST+REAL";
            bool hasReal = IsRealMinuteSource(oldSource) || IsRealMinuteSource(incomingSource);

            if (hasHist && hasReal)
                return "HIST+REAL";

            if (hasReal)
                return "REAL";

            return "HIST";
        }
        

        private TrackedSymbol ToRealtimeMinuteSymbol(TrackedSymbol tick)
        {
            if (tick == null)
                return null;

            DateTime minute = ToMinuteTime(tick.LastUpdated);

            return new TrackedSymbol
            {
                Code = tick.Code,
                LastUpdated = minute,
                LastPrice = tick.LastPrice,
                ClosePrice = tick.LastPrice,
                HighPrice = tick.LastPrice,
                LowPrice = tick.LastPrice,
                LastVolume = Math.Abs(tick.LastVolume),
                AccumulatedVolume = tick.AccumulatedVolume,
                Strength = tick.Strength,
                TotalAskQty = tick.TotalAskQty,
                TotalBidQty = tick.TotalBidQty,
                Side = "REAL_MIN"
            };
        }
        

        private void UpsertTrackedMinute_NoSort(List<TrackedSymbol> list, TrackedSymbol incoming, bool preferRealtime)
        {
            if (list == null || incoming == null)
                return;

            if (list.Count == 0)
            {
                list.Add(incoming);
                return;
            }

            var last = list[list.Count - 1];

            if (last.Code == incoming.Code && last.LastUpdated == incoming.LastUpdated)
            {
                MergeTrackedMinute(last, incoming, preferRealtime);
                return;
            }

            if (incoming.LastUpdated > last.LastUpdated)
            {
                list.Add(incoming);
                return;
            }

            // 보유주 과거분봉/실시간분봉이 섞여 들어올 때만 위치 보정.
            for (int i = list.Count - 2; i >= 0; i--)
            {
                var old = list[i];

                if (old.Code == incoming.Code && old.LastUpdated == incoming.LastUpdated)
                {
                    MergeTrackedMinute(old, incoming, preferRealtime);
                    return;
                }

                if (old.LastUpdated < incoming.LastUpdated)
                {
                    list.Insert(i + 1, incoming);
                    return;
                }
            }

            list.Insert(0, incoming);
        }
        

        private void MergeTrackedMinute(TrackedSymbol old, TrackedSymbol incoming, bool preferRealtime)
        {
            if (old == null || incoming == null)
                return;

            bool oldIsReal = old.Side == "REAL_MIN" || old.Side == "HIST+REAL";
            bool incomingIsReal = incoming.Side == "REAL_MIN" || incoming.Side == "HIST+REAL";

            old.HighPrice = Math.Max(old.HighPrice, incoming.HighPrice);
            old.LowPrice = old.LowPrice <= 0 ? incoming.LowPrice : Math.Min(old.LowPrice, incoming.LowPrice);

            if (preferRealtime && oldIsReal && !incomingIsReal)
            {
                // 실시간 종가 유지
            }
            else
            {
                old.LastPrice = incoming.LastPrice;
                old.ClosePrice = incoming.ClosePrice;
            }

            if (oldIsReal && incomingIsReal)
                old.LastVolume += incoming.LastVolume;
            else
                old.LastVolume = Math.Max(old.LastVolume, incoming.LastVolume);

            old.AccumulatedVolume = Math.Max(old.AccumulatedVolume, incoming.AccumulatedVolume);
            old.Strength = incoming.Strength > 0 ? incoming.Strength : old.Strength;
            old.TotalAskQty = incoming.TotalAskQty > 0 ? incoming.TotalAskQty : old.TotalAskQty;
            old.TotalBidQty = incoming.TotalBidQty > 0 ? incoming.TotalBidQty : old.TotalBidQty;

            if ((old.Side == "M" || old.Side == "HIST") && incomingIsReal)
                old.Side = "HIST+REAL";
            else if (oldIsReal && (incoming.Side == "M" || incoming.Side == "HIST"))
                old.Side = "HIST+REAL";
            else
                old.Side = incoming.Side;
        }
        

        private MinuteCandleRecord ToRealtimeMinuteCandle(TrackedSymbol tick)
        {
            if (tick == null)
                return null;

            DateTime minute = ToMinuteTime(tick.LastUpdated);

            return new MinuteCandleRecord
            {
                Code = tick.Code,
                Name = Context != null && Context.Code == tick.Code ? Context.Name : "",
                CandleTime = minute,
                Interval = "1m",
                Open = tick.LastPrice,
                High = tick.LastPrice,
                Low = tick.LastPrice,
                Close = tick.LastPrice,
                Volume = (long)tick.LastVolume,
                AccumulatedVolume = tick.AccumulatedVolume,
                Strength = tick.Strength,
                TotalAskQty = tick.TotalAskQty,
                TotalBidQty = tick.TotalBidQty,
                Source = "REAL",
                CreatedAt = DateTime.Now
            };
        }
        

        private void RequestRealtimeMinuteChartRefresh(TrackedSymbol minute)
        {
            if (minute == null)
                return;

            // UI 스레드 비동기 Invoke를 사용 중이거나 Chart 컴포넌트가 이벤트를 구독 중일 때
            // 리스트 객체가 레이스 컨디션에 빠지지 않도록 새로 생성해서 던짐
            var candleList = new List<TrackedSymbol> { minute };
            var markers = GetCurrentTradeMarkers() ?? new List<TradeMarkerInfo>();

            RequestChartRefresh?.Invoke(new ChartPayload
            {
                Candles = candleList,
                Markers = markers,
                IsFullRefresh = false // 새로운 분봉 1개만 추가/복사하는 경량 업데이트 지시
            });
        }

        

        private void Kiwoom_OnMinuteHistoryReceived(string windowId, string code, List<MinuteCandleRecord> candles, bool isLast)
        {
            bool isHoldingMinuteRequest =
                !string.IsNullOrWhiteSpace(windowId) &&
                windowId.StartsWith("INV", StringComparison.OrdinalIgnoreCase);

            if (isHoldingMinuteRequest)
            {
                string holdingCode = code;

                if (string.IsNullOrWhiteSpace(holdingCode) && windowId.Contains(":"))
                    holdingCode = windowId.Substring(windowId.IndexOf(":") + 1);

                if (!string.IsNullOrWhiteSpace(holdingCode))
                    HandleHoldingMinuteHistory(windowId, holdingCode, candles, isLast);

                return;
            }

            if (windowId != this.WindowId || code != Context.Code)
                return;

            if (candles != null && candles.Count > 0)
            {
                candles.Sort((a, b) => a.CandleTime.CompareTo(b.CandleTime));

                Db.EnqueueMinuteCandles(candles);

                lock (_syncLock)
                {
                    foreach (var candle in candles)
                        UpsertMinuteCandle_NoSort(_minuteHistoryBuffer, candle, preferRealtime: true);
                }
            }

            if (!isLast)
                return;

            // 분봉 히스토리 재요청 중 들어온 실시간틱을 오늘 REAL 분봉으로 병합한다.
            // 장 시작 전 전일 차트를 비운 뒤 오늘 분봉이 도착하기 전의 틱도 누락하지 않기 위함.
            lock (_realTimeBuffer)
            {
                while (_realTimeBuffer.Count > 0)
                {
                    var bufferedTick = _realTimeBuffer.Dequeue();
                    var realMinute = ToRealtimeMinuteCandle(bufferedTick);
                    if (realMinute != null)
                    {
                        lock (_syncLock)
                        {
                            UpsertMinuteCandle_NoSort(_minuteHistoryBuffer, realMinute, preferRealtime: true);
                        }
                    }
                }
            }

            List<TrackedSymbol> analysisData;
            List<TrackedSymbol> chartData;

            lock (_syncLock)
            {
                // 과거분봉 완료 시점에만 1회 정렬한다.
                _minuteHistoryBuffer.Sort((a, b) => a.CandleTime.CompareTo(b.CandleTime));

                analysisData = _minuteHistoryBuffer
                    .Select(ToTrackedSymbol)
                    .ToList();

                Context.SymbolList.Clear();
                Context.SymbolList.AddRange(analysisData);

                chartData = GetChartMinuteData(analysisData);

                if (chartData.Count > 0)
                {
                    var last = chartData[chartData.Count - 1];

                    _lastChartMinute = last.LastUpdated;
                    _currentMinute = _lastChartMinute;

                    Context.LastPrice = last.LastPrice;
                    Price = OrderPrice = last.LastPrice;
                }
            }

            _minuteTickBuffer.Clear();
            _isHistoryBindingComplete = true;
            IsLoading = false;

            RequestChartRefresh?.Invoke(
                CreateChartPayload(chartData, isFullRefresh: true));

            SyncAutoTradeMinuteCandles(code, "일반 과거분봉 완료");

            Task.Run(async () =>
            {
                await Task.Delay(1500);

                if (Context.Code == code)
                    _marketApi.RequestRecentTicks(this.WindowId, code, ScreenNo, minutes: 5, priority: 2);
            });

            AddLog($"✅ 분봉 차트 바인딩 완료: {code} / 차트 {chartData.Count}개 / 분석 {analysisData.Count}개");
        }
        

        private void HandleHoldingMinuteHistory(string windowId, string code, List<MinuteCandleRecord> candles, bool isLast)
        {
            if (string.IsNullOrWhiteSpace(code))
                code = windowId.Replace("INVMIN:", "");

            var store = GlobalHoldingStore.GetOrCreate(code);

            if (candles != null && candles.Count > 0)
            {
                Db.EnqueueMinuteCandles(candles);

                lock (store.SyncRoot)
                {
                    foreach (var candle in candles)
                    {
                        var item = ToTrackedSymbol(candle);
                        UpsertTrackedMinute_NoSort(store.MinuteList, item, preferRealtime: true);
                    }
                }
            }

            if (!isLast)
                return;

            bool firstMinuteHistoryComplete;
            bool isStoreHistoryLoaded;
            int minuteCount;

            lock (store.SyncRoot)
            {
                // 보유주 과거분봉 완료 시점에만 1회 정렬한다.
                store.MinuteList.Sort((a, b) => a.LastUpdated.CompareTo(b.LastUpdated));

                // 이미 완료된 보유주 분봉 요청의 중복 마지막 응답이면
                // 차트 재바인딩/완료 로그를 반복하지 않는다.
                firstMinuteHistoryComplete = !store.IsMinuteHistoryLoaded;

                store.IsMinuteLoaded = store.MinuteList.Count > 0;
                store.IsMinuteHistoryLoaded = store.IsMinuteLoaded;
                RecalculateHoldingLoadState(store);

                if (store.IsHistoryLoaded)
                    store.HistoryLoadedSource.TrySetResult(true);

                if (store.MinuteList.Count > 0)
                    store.LastTickTime = store.MinuteList[store.MinuteList.Count - 1].LastUpdated;

                isStoreHistoryLoaded = store.IsHistoryLoaded;
                minuteCount = store.MinuteList.Count;
            }

            if (!firstMinuteHistoryComplete)
                return;

            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.DataBind,
                new Action(() =>
                {
                    var holding = AccountHoldings.FirstOrDefault(x => x.Code == code);

                    if (holding != null)
                    {
                        holding.IsHistoryLoading = false;
                        holding.IsHistoryLoaded = isStoreHistoryLoaded;
                    }

                    if (Context.Code == code && minuteCount > 0)
                    {
                        var symbol = new Symbol
                        {
                            Code = code,
                            Name = holding?.Name ?? code,
                            LastPrice = holding?.CurrentPrice.ToString() ?? ""
                        };

                        BindHoldingStoreToChart(store, symbol);
                    }
                }));

            if (Context != null && Context.Code == code && minuteCount > 0)
            {
                MarkAutoTradeDataReady(code);
                SyncAutoTradeMinuteCandles(code, "보유주 과거분봉 완료");
            }

            AddLog($"✅ 보유주 분봉 저장 완료: {code} / {minuteCount}개");
        }
        

        private TrackedSymbol ToTrackedSymbol(MinuteCandleRecord c)
        {
            return new TrackedSymbol
            {
                Code = c.Code,
                LastUpdated = c.CandleTime,
                LastPrice = c.Close,
                ClosePrice = c.Close,
                HighPrice = c.High,
                LowPrice = c.Low,
                LastVolume = c.Volume,
                AccumulatedVolume = c.AccumulatedVolume,
                Strength = c.Strength,
                TotalAskQty = c.TotalAskQty,
                TotalBidQty = c.TotalBidQty,
                Side = string.IsNullOrWhiteSpace(c.Source) ? "HIST" : c.Source
            };
        }
        

        private DateTime ToMinuteTime(DateTime time)
        {
            if (time == default(DateTime))
                return default(DateTime);

            return new DateTime(
                time.Year,
                time.Month,
                time.Day,
                time.Hour,
                time.Minute,
                0);
        }
        

        private DateTime GetMaxMinuteTimeFromCurrentBuffer()
        {
            lock (_syncLock)
            {
                if (_minuteHistoryBuffer == null || _minuteHistoryBuffer.Count == 0)
                    return DateTime.MinValue;

                var last = _minuteHistoryBuffer[_minuteHistoryBuffer.Count - 1];

                if (last == null)
                    return DateTime.MinValue;

                return ToMinuteTime(last.CandleTime);
            }
        }

        

        private DateTime GetMaxMinuteTimeFromHoldingStore(HoldingSymbolContext store)
        {
            if (store == null)
                return DateTime.MinValue;

            if (store.MinuteList == null || store.MinuteList.Count == 0)
                return DateTime.MinValue;

            var last = store.MinuteList[store.MinuteList.Count - 1];

            if (last == null)
                return DateTime.MinValue;

            return ToMinuteTime(last.LastUpdated);
        }

        
    }
}
