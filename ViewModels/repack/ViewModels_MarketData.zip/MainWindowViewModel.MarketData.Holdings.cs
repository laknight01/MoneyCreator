﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void AddRecentTickToHoldingStore_NoLock(HoldingSymbolContext store, TrackedSymbol tick)
        {
            if (store == null || tick == null)
                return;

            store.RecentTickList.Add(CloneTrackedSymbolForAutoTrade(tick));
            AddOrMergeTickFrame_NoLock(store.TickFrameList, tick);

            store.IsRecentTickLoaded = true;
        }
        

        private void TrimHoldingRecentTicks_NoLock(HoldingSymbolContext store)
        {
            if (store == null)
                return;

            DateTime now = store.LastTickTime;

            if (now == default(DateTime))
            {
                if (store.RecentTickList.Count > 0)
                    now = store.RecentTickList[store.RecentTickList.Count - 1].LastUpdated;
                else if (store.TickFrameList.Count > 0)
                    now = store.TickFrameList[store.TickFrameList.Count - 1].Time;
                else
                    return;
            }

            DateTime rawCutoff = now.AddSeconds(-RawRealtimeTickRetentionSeconds);

            store.RecentTickList.RemoveAll(x => x == null || x.LastUpdated < rawCutoff);
            TrimTickFrames_NoLock(store.TickFrameList, now);
        }
        

        private void RecalculateHoldingLoadState(HoldingSymbolContext store)
        {
            if (store == null)
                return;

            // 보유주 리스트의 "로딩중"은 분봉 로딩만 기준으로 종료
            // 최근틱은 없을 수 있으므로 필수 조건에서 제외
            bool loaded = store.IsMinuteLoaded || store.MinuteList.Count > 0;

            store.IsHistoryLoaded = loaded;
            store.IsLoadingHistory = !loaded;

            if (loaded)
                store.HistoryLoadedSource.TrySetResult(true);
        }
        

        private void RequestHoldingHistoryAndRealtime(HoldingInfo h)
        {
            if (h == null || string.IsNullOrWhiteSpace(h.Code))
                return;

            var store = GlobalHoldingStore.GetOrCreate(h.Code, h.Name);

            bool isMarketOpen = IsMarketOpenForRealtime();

            bool requestMinute = false;
            bool requestRecentTick = false;
            bool registerRealtime = false;

            lock (store.SyncRoot)
            {
                if (store.MinuteList.Count > 0 || store.IsMinuteLoaded)
                {
                    store.IsMinuteLoaded = true;
                    store.IsMinuteHistoryLoaded = true;
                    store.IsHistoryLoaded = true;
                    store.IsLoadingHistory = false;

                    h.IsHistoryLoaded = true;
                    h.IsHistoryLoading = false;
                }
                else if (!store.IsLoadingHistory)
                {
                    store.IsLoadingHistory = true;
                    store.IsHistoryLoaded = false;
                    store.IsMinuteLoaded = false;
                    store.IsMinuteHistoryLoaded = false;
                    store.HistoryLoadedSource = new TaskCompletionSource<bool>();

                    h.IsHistoryLoaded = false;
                    h.IsHistoryLoading = true;

                    requestMinute = true;
                }
                else
                {
                    h.IsHistoryLoaded = store.IsHistoryLoaded;
                    h.IsHistoryLoading = true;
                }

                if (isMarketOpen)
                {
                    registerRealtime = true;

                    if (store.RecentTickList.Count == 0 && !store.IsRecentTickLoaded)
                        requestRecentTick = true;
                }
                else
                {
                    // 장외에는 최근틱이 없어도 로딩중으로 두면 안 됨
                    store.IsRecentTickLoaded = true;
                }
            }

            if (registerRealtime)
            {
                _marketApi.RegisterInventoryTracking(
                    "COMMON",
                    h.Code,
                    "9999");
            }

            if (requestMinute)
            {
                _marketApi.RequestMinuteCandles(
                    $"INVMIN:{h.Code}",
                    h.Code,
                    _marketApi.GetScreenNo(),
                    daysToLoad: 2,
                    maxRows: 0,
                    priority: 0);
            }

            // 보유주 최근 5분 과거틱도 분봉 요청과 동시에 넣지 않고 지연시켜 낮은 우선순위로 보강한다.
            if (requestRecentTick)
            {
                Task.Run(async () =>
                {
                    await Task.Delay(300);
                    _marketApi.RequestRecentTicks(
                        $"INVTICK:{h.Code}",
                        h.Code,
                        _marketApi.GetScreenNo(),
                        minutes: 5,
                        priority: 2);
                });
            }

            // 실제로 신규 요청을 넣은 경우에만 로그를 남긴다.
            // 잔고 갱신/창 전환으로 이 메서드가 반복 호출되어도 로그가 무한히 쌓이지 않게 한다.
            if (requestMinute || requestRecentTick)
            {
                AddLog(isMarketOpen
                    ? $"📦 보유주 분봉/최근틱 요청: {h.Name}({h.Code})"
                    : $"📦 보유주 분봉만 요청(장외): {h.Name}({h.Code})");
            }
        }
        

        private void Kiwoom_OnInventoryTickReceived(TrackedSymbol tick)
        {
            if (tick == null || string.IsNullOrWhiteSpace(tick.Code))
                return;

            var store = GlobalHoldingStore.GetOrCreate(tick.Code);

            ResetHoldingChartForNewTradingDayIfNeeded(store, tick);

            DateTime tickMinute = ToMinuteTime(tick.LastUpdated);

            DateTime savedMaxMinute;

            lock (store.SyncRoot)
            {
                savedMaxMinute = GetMaxMinuteTimeFromHoldingStore(store);
            }

            bool shouldRefreshChart = savedMaxMinute < tickMinute;

            TrackedSymbol latestMinute = null;

            lock (store.SyncRoot)
            {
                AddRecentTickToHoldingStore_NoLock(store, tick);
                TrimHoldingRecentTicks_NoLock(store);

                UpsertHoldingMinuteCandle_NoSort(store, tick);

                store.LastTickTime = tick.LastUpdated;

                if (shouldRefreshChart &&
                    Context != null &&
                    Context.Code == tick.Code &&
                    store.MinuteList.Count > 0)
                {
                    latestMinute = store.MinuteList[store.MinuteList.Count - 1];

                    if (latestMinute != null)
                    {
                        DateTime latestMinuteTime = ToMinuteTime(latestMinute.LastUpdated);

                        _lastChartMinute = latestMinuteTime;
                        _currentMinute = latestMinuteTime;
                        latestMinute.LastUpdated = latestMinuteTime;
                    }
                }
            }

            var holding = AccountHoldings?.FirstOrDefault(h =>
                h != null &&
                h.Code == tick.Code);

            if (holding != null)
            {
                holding.CurrentPrice = tick.LastPrice;
                holding.IsHistoryLoading = store.IsLoadingHistory;
                holding.IsHistoryLoaded = store.IsHistoryLoaded;
            }

            if (Context != null && Context.Code == tick.Code)
            {
                UpdateCurrentSymbolFromTick(tick, isLoading: false);

                if (shouldRefreshChart && latestMinute != null && _isHistoryBindingComplete)
                {
                    RequestRealtimeMinuteChartRefresh(latestMinute);
                    SyncAutoTradeMinuteCandles(tick.Code, "보유주 실시간 분봉 갱신");
                }

                TryEnqueueAutoTradeTick(tick);
            }
        }


        private void ClearHoldingStoreForReload(HoldingInfo holding)
        {
            if (holding == null || string.IsNullOrWhiteSpace(holding.Code))
                return;

            var store = GlobalHoldingStore.GetOrCreate(holding.Code, holding.Name);

            lock (store.SyncRoot)
            {
                store.SymbolList.Clear();
                store.MinuteList.Clear();
                store.RecentTickList.Clear();
                store.TickFrameList.Clear();
                store.PendingTicks.Clear();

                store.LastTickTime = DateTime.MinValue;

                store.IsHistoryLoaded = false;
                store.IsLoadingHistory = false;
                store.IsMinuteLoaded = false;
                store.IsRecentTickLoaded = false;
                store.IsMinuteHistoryLoaded = false;
                store.HistoryLoadedSource = new TaskCompletionSource<bool>();
            }

            holding.IsHistoryLoaded = false;
            holding.IsHistoryLoading = false;
        }
        
    }
}
