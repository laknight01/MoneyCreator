﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private readonly Queue<TrackedSymbol> _recentRealtimeTicks = new Queue<TrackedSymbol>();
        private readonly List<TickFrame> _recentTickFrames = new List<TickFrame>();
        private readonly object _recentRealtimeTickLock = new object();

        private const int RawRealtimeTickRetentionSeconds = 30;
        private const int TickFrameRetentionMinutes = 5;

        private readonly List<MinuteCandleRecord> _minuteHistoryBuffer = new List<MinuteCandleRecord>();
        private readonly List<TrackedSymbol> _minuteTickBuffer = new List<TrackedSymbol>();

        private bool _isDailyResetDone = false;
        private bool _isNewTradingDayReloading = false;

        private DateTime _currentMinute = DateTime.MinValue;
        private DateTime _lastChartMinute = DateTime.MinValue;

        private readonly ConcurrentDictionary<string, int> _requestTokens = new ConcurrentDictionary<string, int>();
        private readonly object _syncLock = new object();


        private bool IsCurrentWindowTick(string windowId, TrackedSymbol tick)
        {
            if (tick == null)
                return false;

            if (windowId != this.WindowId)
                return false;

            return Context != null && tick.Code == Context.Code;
        }

        private void UpdateCurrentSymbolFromTick(TrackedSymbol tick, bool isLoading)
        {
            if (tick == null || Context == null)
                return;

            Context.LastPrice = tick.LastPrice;
            Context.Strength = tick.Strength;
            IsLoading = isLoading;
        }

        private void UpdateAccountHoldingPrice(string code, double price)
        {
            if (AccountHoldings == null || string.IsNullOrWhiteSpace(code))
                return;

            var holding = AccountHoldings.FirstOrDefault(h => h != null && h.Code == code);
            if (holding != null)
                holding.CurrentPrice = price;
        }

        private void BufferRealtimeTick(TrackedSymbol tick)
        {
            if (tick == null)
                return;

            lock (_realTimeBuffer)
            {
                _realTimeBuffer.Enqueue(tick);
            }
        }

        private TrackedSymbol GetLatestCurrentMinuteForChart_NoLock()
        {
            if (_minuteHistoryBuffer.Count == 0)
                return null;

            var latestMinute = ToTrackedSymbol(_minuteHistoryBuffer[_minuteHistoryBuffer.Count - 1]);
            if (latestMinute == null)
                return null;

            DateTime latestMinuteTime = ToMinuteTime(latestMinute.LastUpdated);
            _lastChartMinute = latestMinuteTime;
            _currentMinute = latestMinuteTime;
            latestMinute.LastUpdated = latestMinuteTime;

            return latestMinute;
        }

        private List<TrackedSymbol> GetOrderedValidTicks(List<TrackedSymbol> ticks, string code)
        {
            if (ticks == null || ticks.Count == 0)
                return new List<TrackedSymbol>();

            return ticks
                .Where(x => x != null && x.Code == code)
                .OrderBy(x => x.LastUpdated)
                .ToList();
        }

        private DateTime GetLatestTickTimeOrNow(List<TrackedSymbol> ticks)
        {
            if (ticks != null && ticks.Count > 0)
                return ticks[ticks.Count - 1].LastUpdated;

            return DateTime.Now;
        }
    }
}
