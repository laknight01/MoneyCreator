﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void Kiwoom_OnRealPriceReceived(string code, string windowId, double currentPrice, int volume, DateTime LastUpdated)
        {
            if (string.IsNullOrWhiteSpace(code))
                return;

            Application.Current.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    var holding = AccountHoldings.FirstOrDefault(h =>
                        h != null && h.Code == code);

                    if (holding != null)
                    {
                        int index = AccountHoldings.IndexOf(holding);

                        holding.CurrentPrice = currentPrice;

                        if (index >= 0)
                            AccountHoldings[index] = holding;

                        if (Context.CurrentHold != null && Context.CurrentHold.Code == code)
                            Context.CurrentHold = holding;
                    }

                    if (Context != null && Context.Code == code)
                        Context.LastPrice = currentPrice;
                }),
                DispatcherPriority.Background);
        }
        

        private void Kiwoom_OnHogaReceived(string wId, HogaData data)
        {
            if (data == null)
                return;

            if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
                return;

            if (data.Code != Context.Code)
                return;

            OnHogaReceived(wId, data);
        }
        

        private void OnInitialHistoryReceived_Handler(List<TrackedSymbol> history, bool islast)
        {
            IsLoading = true;

            if (history == null || history.Count == 0)
            {
                _isHistoryBindingComplete = true;
                return;
            }

            string key = $"{WindowId}_{Context.Code}";
            int currentToken = _requestTokens.AddOrUpdate(key, 1, (_, old) => old + 1);

            lock (_syncLock)
            {
                foreach (var tick in history)
                {
                    Context.SymbolList.Add(tick);
                }
            }

            Task.Run(async () =>
            {
                if (!_requestTokens.TryGetValue(key, out var latest) || latest != currentToken)
                    return;

                if (!islast)
                    return;

                await Application.Current.Dispatcher.InvokeAsync(async () =>
                {
                    try
                    {
                        if (Context.SymbolList.Count > 0)
                        {
                            Context.LastPrice = Context.SymbolList.Last().LastPrice;
                            Price = OrderPrice = Context.LastPrice;
                        }

                        // 로딩 중 수신된 실시간 틱 병합 (원본틱 유지)
                        lock (_realTimeBuffer)
                        {
                            while (_realTimeBuffer.Count > 0)
                            {
                                var bTick = _realTimeBuffer.Dequeue();
                                AddTickToBuffer(bTick);
                            }
                        }

                        lock (_syncLock)
                        {
                            Context.SymbolList.Sort((x, y) => x.LastUpdated.CompareTo(y.LastUpdated));
                        }

                        List<TrackedSymbol> chartData;
                        lock (_syncLock)
                        {
                            chartData = AggregateToMinuteBars(Context.SymbolList);

                            if (chartData.Count > 0)
                                _lastChartMinute = chartData.Last().LastUpdated;
                        }

                        // 실시간 분봉 시작 기준 동기화
                        _minuteTickBuffer.Clear();
                        _currentMinute = _lastChartMinute;

                        // 차트는 분봉 데이터로 렌더
                        RequestChartRefresh?.Invoke(CreateChartPayload(chartData, isFullRefresh: true));

                        _isHistoryBindingComplete = true;

                        AddLog($"✅ 최종 차트 바인딩 완료: 원본틱 {Context.SymbolList.Count}개 / 차트 {chartData.Count}개");
                    }
                    finally
                    {
                        IsLoading = false;
                    }
                });
            });
        }
        
    }
}
