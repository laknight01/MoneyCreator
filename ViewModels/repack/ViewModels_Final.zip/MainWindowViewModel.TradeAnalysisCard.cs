﻿using AxKHOpenAPILib;
using HarfBuzzSharp;
using MoneyCreator.AutoTrading;
using MoneyCreator.Biz;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        // ============================================================
        // 자동매매 분석 카드 바인딩 속성
        // - XAML의 TradeCardAccentBrush / TradeCard* 바인딩 대상
        // - AddAutoTradeAnalysisLog()에서 최신 분석 로그를 파싱해 갱신한다.
        // ============================================================
        private Brush _tradeCardAccentBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(36, 52, 71));
        public Brush TradeCardAccentBrush
        {
            get => _tradeCardAccentBrush;
            set => SetProperty(ref _tradeCardAccentBrush, value);
        }
        private Brush _tradeCardActionBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(220, 238, 255));
        public Brush TradeCardActionBrush
        {
            get => _tradeCardActionBrush;
            set => SetProperty(ref _tradeCardActionBrush, value);
        }
        private Brush _tradeCardProfitBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(220, 238, 255));
        public Brush TradeCardProfitBrush
        {
            get => _tradeCardProfitBrush;
            set => SetProperty(ref _tradeCardProfitBrush, value);
        }
        private string _tradeCardUpdatedAt = "--:--:--";
        public string TradeCardUpdatedAt
        {
            get => _tradeCardUpdatedAt;
            set => SetProperty(ref _tradeCardUpdatedAt, value);
        }
        private string _tradeCardTitle = "분석 대기";
        public string TradeCardTitle
        {
            get => _tradeCardTitle;
            set => SetProperty(ref _tradeCardTitle, value);
        }
        private string _tradeCardAction = "HOLD";
        public string TradeCardAction
        {
            get => _tradeCardAction;
            set => SetProperty(ref _tradeCardAction, value);
        }
        private string _tradeCardCode = "-";
        public string TradeCardCode
        {
            get => _tradeCardCode;
            set => SetProperty(ref _tradeCardCode, value);
        }
        private string _tradeCardPrice = "-";
        public string TradeCardPrice
        {
            get => _tradeCardPrice;
            set => SetProperty(ref _tradeCardPrice, value);
        }
        private string _tradeCardProfitRate = "-";
        public string TradeCardProfitRate
        {
            get => _tradeCardProfitRate;
            set => SetProperty(ref _tradeCardProfitRate, value);
        }
        private string _tradeCardScore = "-";
        public string TradeCardScore
        {
            get => _tradeCardScore;
            set => SetProperty(ref _tradeCardScore, value);
        }
        private string _tradeCardHoldingQty = "-";
        public string TradeCardHoldingQty
        {
            get => _tradeCardHoldingQty;
            set => SetProperty(ref _tradeCardHoldingQty, value);
        }
        private string _tradeCardStrength = "-";
        public string TradeCardStrength
        {
            get => _tradeCardStrength;
            set => SetProperty(ref _tradeCardStrength, value);
        }
        private string _tradeCardVolumeRatio = "-";
        public string TradeCardVolumeRatio
        {
            get => _tradeCardVolumeRatio;
            set => SetProperty(ref _tradeCardVolumeRatio, value);
        }
        private string _tradeCardOneMinuteChange = "-";
        public string TradeCardOneMinuteChange
        {
            get => _tradeCardOneMinuteChange;
            set => SetProperty(ref _tradeCardOneMinuteChange, value);
        }
        private string _tradeCardThreeMinuteChange = "-";
        public string TradeCardThreeMinuteChange
        {
            get => _tradeCardThreeMinuteChange;
            set => SetProperty(ref _tradeCardThreeMinuteChange, value);
        }
        private string _tradeCardBidAskRatio = "-";
        public string TradeCardBidAskRatio
        {
            get => _tradeCardBidAskRatio;
            set => SetProperty(ref _tradeCardBidAskRatio, value);
        }
        private string _tradeCardReason = "아직 분석 로그가 없습니다.";
        public string TradeCardReason
        {
            get => _tradeCardReason;
            set => SetProperty(ref _tradeCardReason, value);
        }
        private string _tradeCardPhase = "-";
        public string TradeCardPhase
        {
            get => _tradeCardPhase;
            set => SetProperty(ref _tradeCardPhase, value);
        }
        private string _tradeCardMarketPhase = "-";
        public string TradeCardMarketPhase
        {
            get => _tradeCardMarketPhase;
            set => SetProperty(ref _tradeCardMarketPhase, value);
        }
        private string _tradeCardTradeMode = "-";
        public string TradeCardTradeMode
        {
            get => _tradeCardTradeMode;
            set => SetProperty(ref _tradeCardTradeMode, value);
        }
        private string _tradeCardStrategy = "-";
        public string TradeCardStrategy
        {
            get => _tradeCardStrategy;
            set => SetProperty(ref _tradeCardStrategy, value);
        }
        private Brush MakeBrush(byte r, byte g, byte b)
        {
            var brush =
                new SolidColorBrush(System.Windows.Media.Color.FromRgb(r, g, b));

            if (brush.CanFreeze)
                brush.Freeze();

            return brush;
        }
        private string GetLogField(Dictionary<string, string> fields, string key, string fallback = "-")
        {
            if (fields == null || string.IsNullOrWhiteSpace(key))
                return fallback;

            return fields.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value)
                ? value.Trim()
                : fallback;
        }
        private Dictionary<string, string> ParseAutoTradeAnalysisFields(string msg)
        {
            var result = new Dictionary<string, string>();

            if (string.IsNullOrWhiteSpace(msg))
                return result;

            string text = msg;

            if (text.StartsWith("[틱분석]"))
                text = text.Substring("[틱분석]".Length).Trim();

            var parts = text.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var part in parts)
            {
                string item = part.Trim();

                if (string.IsNullOrWhiteSpace(item))
                    continue;

                int eqIndex = item.IndexOf('=');
                if (eqIndex <= 0)
                    continue;

                string key = item.Substring(0, eqIndex).Trim();
                string value = item.Substring(eqIndex + 1).Trim();

                if (string.IsNullOrWhiteSpace(key))
                    continue;

                result[key] = value;
            }

            return result;
        }
        private void UpdateTradeAnalysisCardFromLog(string msg)
        {
            if (string.IsNullOrWhiteSpace(msg))
                return;

            bool isTickAnalysis = msg.Contains("종목=") || msg.Contains("[틱분석]");
            bool isSignalLog = msg.StartsWith("[Signal]", StringComparison.OrdinalIgnoreCase);

            if (!isTickAnalysis && !isSignalLog)
            {
                Application.Current?.Dispatcher.BeginInvoke(
                    DispatcherPriority.DataBind,
                    new Action(() =>
                    {
                        TradeCardUpdatedAt = DateTime.Now.ToString("HH:mm:ss");

                        TradeCardTitle =
                            Context != null && !string.IsNullOrWhiteSpace(Context.Name)
                                ? Context.Name
                                : "자동매매 분석";

                        TradeCardCode =
                            Context != null && !string.IsNullOrWhiteSpace(Context.Code)
                                ? Context.Code
                                : "-";

                        TradeCardReason = msg;

                        ApplyTradeCardBrushes(TradeCardAction, TradeCardProfitRate);
                    }));

                return;
            }

            Application.Current?.Dispatcher.BeginInvoke(DispatcherPriority.DataBind,
                new Action(() =>
                {
                    TradeCardUpdatedAt = DateTime.Now.ToString("HH:mm:ss");

                    if (isSignalLog)
                    {
                        var tokens = msg.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                        if (tokens.Length >= 2)
                            TradeCardAction = tokens[1];

                        string parsedCode = null;

                        foreach (var token in tokens)
                        {
                            string cleaned = token.Trim();

                            if (Regex.IsMatch(cleaned, @"^\d{6}$"))
                            {
                                parsedCode = cleaned;
                                break;
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(parsedCode))
                        {
                            TradeCardCode = parsedCode;

                            TradeCardTitle =
                                Context != null &&
                                Context.Code == parsedCode &&
                                !string.IsNullOrWhiteSpace(Context.Name)
                                    ? Context.Name
                                    : parsedCode;
                        }
                        else
                        {
                            // 코드가 없는 Signal 로그에서는 기존 종목정보 유지.
                            // Pullback/Breakout 같은 전략명을 Title/Code에 넣지 않는다.
                            TradeCardCode =
                                Context != null && !string.IsNullOrWhiteSpace(Context.Code)
                                    ? Context.Code
                                    : TradeCardCode;

                            TradeCardTitle =
                                Context != null && !string.IsNullOrWhiteSpace(Context.Name)
                                    ? Context.Name
                                    : TradeCardTitle;
                        }

                        var scoreMatch = Regex.Match(msg, @"score=(\d+)");
                        if (scoreMatch.Success)
                            TradeCardScore = scoreMatch.Groups[1].Value;

                        var slashParts = msg.Split('/');

                        if (slashParts.Length >= 2)
                            TradeCardStrategy = slashParts[1].Trim();

                        if (slashParts.Length >= 3)
                            TradeCardReason = slashParts[2].Trim();

                        if (string.IsNullOrWhiteSpace(TradeCardPhase))
                            TradeCardPhase = "-";

                        if (string.IsNullOrWhiteSpace(TradeCardMarketPhase))
                            TradeCardMarketPhase = "-";

                        if (string.IsNullOrWhiteSpace(TradeCardTradeMode))
                            TradeCardTradeMode = "-";

                        ApplyTradeCardBrushes(TradeCardAction, TradeCardProfitRate);
                        return;
                    }

                    var fields = ParseAutoTradeAnalysisFields(msg);

                    string code = GetLogField(fields, "종목", Context?.Code ?? "-");
                    string action = GetLogField(fields, "판단", "HOLD");
                    string profitRate = GetLogField(fields, "수익률", "-");

                    string marketTrend = GetLogField(fields, "시장", "-");
                    string symbolPhase = GetLogField(fields, "종목국면", "-");

                    TradeCardCode = IsValidStockCode(code)
                        ? code
                        : Context?.Code ?? "-";

                    TradeCardTitle =
                        Context != null &&
                        Context.Code == TradeCardCode &&
                        !string.IsNullOrWhiteSpace(Context.Name)
                            ? Context.Name
                            : TradeCardCode;

                    TradeCardAction = action;
                    TradeCardScore = GetLogField(fields, "점수", "-");
                    TradeCardPrice = GetLogField(fields, "현재가", "-");
                    TradeCardHoldingQty = GetLogField(fields, "보유수량", "-");
                    TradeCardProfitRate = profitRate;
                    TradeCardOneMinuteChange = GetLogField(fields, "1분등락", "-");
                    TradeCardThreeMinuteChange = GetLogField(fields, "3분등락", "-");
                    TradeCardStrength = GetLogField(fields, "체결강도", "-");
                    TradeCardVolumeRatio = GetLogField(fields, "거래량비율", "-");
                    TradeCardBidAskRatio = GetLogField(fields, "매수우위", "-");

                    // 시장 전체 상태: Bear / Bull / Panic / Sideways 등
                    TradeCardPhase = string.IsNullOrWhiteSpace(marketTrend)
                        ? "-"
                        : marketTrend;

                    // 종목 자체 국면: Pullback / Breakout / Unstable 등
                    TradeCardMarketPhase = string.IsNullOrWhiteSpace(symbolPhase)
                        ? "-"
                        : symbolPhase;

                    TradeCardTradeMode = GetLogField(fields, "매매모드", GetLogField(fields, "TradeMode", "-"));
                    TradeCardStrategy = GetLogField(fields, "전략", "-");
                    TradeCardReason = GetLogField(fields, "판단사유", msg);

                    ApplyTradeCardBrushes(action, profitRate);
                }));
        }
        private bool IsValidStockCode(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return false;

            return Regex.IsMatch(code.Trim(), @"^\d{6}$");
        }

        private void ApplyTradeCardBrushes(string action, string profitRateText)
        {
            action = action ?? string.Empty;

            if (action.IndexOf("BUY", StringComparison.OrdinalIgnoreCase) >= 0 ||
                action.Contains("매수"))
            {
                TradeCardAccentBrush = MakeBrush(22, 59, 42);

                TradeCardActionBrush = MakeBrush(103, 245, 164);
            }
            else if (action.IndexOf("SELL", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     action.Contains("매도"))
            {
                TradeCardAccentBrush = MakeBrush(74, 31, 36);
                TradeCardActionBrush = MakeBrush(255, 138, 138);
            }
            else
            {
                TradeCardAccentBrush = MakeBrush(36, 52, 71);
                TradeCardActionBrush = MakeBrush(220, 238, 255);
            }

            double profitRate;
            string normalized = (profitRateText ?? string.Empty)
                .Replace("%", "")
                .Replace(",", "")
                .Trim();

            if (double.TryParse(normalized, out profitRate))
                TradeCardProfitBrush = profitRate >= 0
                    ? MakeBrush(115, 255, 154)
                    : MakeBrush(255, 119, 119);
            else
                TradeCardProfitBrush = MakeBrush(220, 238, 255);
        }
    }
}
