﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public sealed class ChartPayload
    {
        public List<TrackedSymbol> Candles { get; set; } = new List<TrackedSymbol>();
        public List<TradeMarkerInfo> Markers { get; set; } = new List<TradeMarkerInfo>();
        public bool IsFullRefresh { get; set; }
    }

    public partial class MainWindowViewModel : ViewModelBase
    {
        private DateTime _lastMarketAnalysisLogTime = DateTime.MinValue;
        private string _lastMarketAnalysisLogKey = string.Empty;
        private readonly IMarketApiService _marketApi;
        private AxKHOpenAPI _api;
        private bool _isMainLoading;
        private string _mainLoadingMessage;
        private readonly object _initialLoadLock = new object();
        private readonly HashSet<string> _initialLoadTokens = new HashSet<string>();
        // [추가] 멀티 윈도우 식별을 위한 고유 ID
        public Window HostWindow { get; set; }
        public string WindowId { get; } = Guid.NewGuid().ToString("N").Substring(0, 8);
        public ObservableCollection<string> Logs { get; } = new ObservableCollection<string>();
        // 자동매매/AI 분석 전용 로그
        // - 화면 하단 "AI 분석" 영역에 표시
        // - 최대 1000개 유지, 초과분은 오래된 항목부터 자동 삭제
        public ObservableCollection<string> AutoTradeAnalysisLogs { get; } = new ObservableCollection<string>();
        public IReadOnlyList<string> AutoTradeLogModeOptions { get; } = new List<string> { "매매만", "전체" };
        private string _selectedAutoTradeLogMode = "전체";
        private bool _initialMainLoadingStarted;
        private bool _initialMainLoadingCompleted;

        public string SelectedAutoTradeLogMode
        {
            get => _selectedAutoTradeLogMode;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    value = "매매만";

                if (SetProperty(ref _selectedAutoTradeLogMode, value))
                {
                    _autoTradeSettings.AnalysisLogMode = value == "전체"
                        ? AutoTradeAnalysisLogMode.All
                        : AutoTradeAnalysisLogMode.TradeOnly;

                    _autoTradeController?.UpdateSettings(_autoTradeSettings);
                    OnPropertyChanged(nameof(IsAutoTradeLogTradeOnly));
                    OnPropertyChanged(nameof(IsAutoTradeLogAll));
                    AddAutoTradeAnalysisLog($"🔎 분석 로그 모드: {value}");
                }
            }
        }

        public bool IsMainLoading
        {
            get => _isMainLoading;
            set => SetProperty(ref _isMainLoading, value);
        }

        public string MainLoadingMessage
        {
            get => _mainLoadingMessage;
            set => SetProperty(ref _mainLoadingMessage, value);
        }
        public bool IsAutoTradeLogTradeOnly
        {
            get => SelectedAutoTradeLogMode == "매매만";
            set
            {
                if (value)
                    SelectedAutoTradeLogMode = "매매만";
            }
        }
        public bool IsAutoTradeLogAll
        {
            get => SelectedAutoTradeLogMode == "전체";
            set
            {
                if (value)
                    SelectedAutoTradeLogMode = "전체";
            }
        }

        private MarketIndexInfo _kospi = new MarketIndexInfo
        {
            Code = "001",
            Name = "KOSPI"
        };

        public MarketIndexInfo Kospi
        {
            get => _kospi;
            set => SetProperty(ref _kospi, value);
        }

        private MarketIndexInfo _kosdaq = new MarketIndexInfo
        {
            Code = "101",
            Name = "KOSDAQ"
        };

        public MarketIndexInfo Kosdaq
        {
            get => _kosdaq;
            set => SetProperty(ref _kosdaq, value);
        }

        public ObservableCollection<Symbol> Symbols { get; } = new ObservableCollection<Symbol>();
        public ObservableCollection<AiResult> AiSelectedSymbols { get; } = new ObservableCollection<AiResult>();
        public ObservableCollection<HoldingInfo> AccountHoldings { get; set; } = new ObservableCollection<HoldingInfo>();
        public ObservableCollection<OrderInfo> OrderHistory { get; set; } = new ObservableCollection<OrderInfo>();
        public System.Collections.IEnumerable Reservelist => new System.Collections.ObjectModel.ObservableCollection<string>();
        private readonly HashSet<string> _tradeMarkerKeys = new HashSet<string>();
        private readonly object _latestHogaLock = new object();
        private HogaData _latestHogaForAutoTrade;
        private DateTime _lastHogaUiUpdateTime = DateTime.MinValue;
        private StockDbManager Db => _marketApi.DbManager;
        private bool _isLoading;
        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }
        private bool IsMarketOpenForRealtime()
        {
            var now = DateTime.Now.TimeOfDay;

            return now >= new TimeSpan(9, 0, 0) &&
                   now <= new TimeSpan(15, 20, 0);
        }
        public ICommand ConnectCommand { get; }
        public ICommand SearchCommand { get; }
        public ICommand AnalyzeCommand { get; }
        public ICommand SetQtyCommand => new RelayCommand<string>((param) =>
        {
            string[] args = param.Split(',');
            string type = args[0];
            double percent = double.Parse(args[1]) / 100.0;

            if (type == "BUY")
            {
                if (Price <= 0) return;
                Quantity = (int)((CurrentBalance / Price) * percent);
            }
            else
            {
                Quantity = (int)(_holdingQty * percent);
            }
        });
        public ICommand AutoTradingToggleCommand { get; private set; }
        private ICommand _openAllHoldingsCommand;
        public ICommand OpenAllHoldingsCommand => _openAllHoldingsCommand ??= new RelayCommand(async _ =>
        {
            // 버튼 중복 클릭 방지 등을 위해 여기서 직접 Execute를 호출하거나 로직을 태워
            await ExecuteOpenAllHoldings();
        });
        public ICommand AiToggleCommand { get; }
        private string _searchQuery;
        private bool _isSearchPopupOpen;
        private List<DateTime> _timeBuffer = new List<DateTime>();
        public event Action<ChartPayload> RequestChartRefresh;
        public event Action OnChartResetRequired;
        public event Action<DateTime, double, bool> TradeMarkerRequested;
        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                if (_searchQuery == value)
                    return;

                _searchQuery = value;
                OnPropertyChanged();

                UpdateSearchResults(value);
            }
        }
        public string AccountPassword
        {
            get => _accountPassword;
            set { _accountPassword = value; OnPropertyChanged(); }
        }
        #region 검색
        public bool IsSearchPopupOpen
        {
            get => _isSearchPopupOpen;
            set
            {
                if (_isSearchPopupOpen == value)
                    return;

                _isSearchPopupOpen = value;
                OnPropertyChanged();
            }
        }
        #endregion
        #region 주문
        private long _deposit;
        private int _holdingQty;
        public int HoldingQty
        {
            get => _holdingQty;
            set
            {
                _holdingQty = value; OnPropertyChanged(nameof(HoldingQty));
            }
        }
        private double _price;
        private int _quantity;
        public StockContext Context { get; } = new StockContext();
        public double Price { get => Context.LastPrice; set { Context.LastPrice = (int)value; OnPropertyChanged(); } }
        private double _orderPrice;
        public double OrderPrice
        {
            get => _orderPrice;
            set { _orderPrice = value; OnPropertyChanged(); OnPropertyChanged(nameof(TotalAmount)); }
        }
        public int Quantity { get => _quantity; set { SetProperty(ref _quantity, value); OnPropertyChanged(nameof(TotalAmount)); } }
        public double TotalAmount => OrderPrice * Quantity;
        public string ScreenNo { get; set; }
        #endregion
        private bool BeginInitialMainLoading()
        {
            if (_initialMainLoadingStarted || _initialMainLoadingCompleted)
                return false;

            _initialMainLoadingStarted = true;

            lock (_initialLoadLock)
            {
                _initialLoadTokens.Clear();

                _initialLoadTokens.Add("CASH");
                _initialLoadTokens.Add("HOLDINGS");
                _initialLoadTokens.Add("ORDERS");
            }

            MainLoadingMessage = "초기 계좌 / 보유종목 / 주문내역을 불러오는 중입니다...";
            IsMainLoading = true;

            return true;
        }
        private void CompleteInitialMainLoadingToken(string token)
        {
            if (!_initialMainLoadingStarted || _initialMainLoadingCompleted)
                return;

            if (string.IsNullOrWhiteSpace(token))
                return;

            bool completed;

            lock (_initialLoadLock)
            {
                _initialLoadTokens.Remove(token);
                completed = _initialLoadTokens.Count == 0;
            }

            if (!completed)
                return;

            _initialMainLoadingCompleted = true;

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    MainLoadingMessage = string.Empty;
                    IsMainLoading = false;
                }));
        }

        private void RefreshOrderHistory()
        {
            var sorted = OrderHistory
                .Where(x => x != null)
                .OrderByDescending(x => x.OrderTime)
                .ToList();

            OrderHistory.Clear();

            foreach (var order in sorted)
                OrderHistory.Add(order);
        }

        private void AddOrUpdateOrderHistory(OrderInfo order)
        {
            if (order == null)
                return;

            order.OrderTime = NormalizeOrderTime(order.OrderTime);

            if (string.IsNullOrWhiteSpace(order.OrderNo))
                return;

            var existing = OrderHistory.FirstOrDefault(x =>
                x != null &&
                !string.IsNullOrWhiteSpace(x.OrderNo) &&
                x.OrderNo == order.OrderNo);

            if (existing == null)
            {
                OrderHistory.Add(order);
                return;
            }

            existing.TradeGroupId = order.TradeGroupId;
            existing.OrderTime = order.OrderTime;
            existing.Code = order.Code;
            existing.Name = order.Name;
            existing.OrderType = order.OrderType;
            existing.Qty = order.Qty;
            existing.ExecQty = order.ExecQty;
            existing.Price = order.Price;
            existing.ExecPrice = order.ExecPrice;
            existing.Status = order.Status;
            existing.UntradedQty = order.UntradedQty;
            existing.OrderStatus = order.OrderStatus;
            existing.StrategyName = order.StrategyName;
            existing.Fee = order.Fee;
            existing.Tax = order.Tax;
            existing.ParentOrderNo = order.ParentOrderNo;
            existing.TiRexDirection = order.TiRexDirection;
            existing.TiRexConfidence = order.TiRexConfidence;
            existing.TiRexPredictedReturn = order.TiRexPredictedReturn;
        }

        public ObservableCollection<HogaItem> AskList { get; } = new ObservableCollection<HogaItem>();
        public ObservableCollection<HogaItem> BidList { get; } = new ObservableCollection<HogaItem>();
        private Queue<TrackedSymbol> _realTimeBuffer = new Queue<TrackedSymbol>();
        private bool _isHistoryBindingComplete = false;
        private long _totalAskQty;
        private long _totalBidQty;
        public long TotalAskQty { get => _totalAskQty; set { _totalAskQty = value; OnPropertyChanged(); } }
        public long TotalBidQty { get => _totalBidQty; set { _totalBidQty = value; OnPropertyChanged(); } }
        public void OnHogaReceived(string windowId, HogaData data)
        {
            if (data == null)
                return;

            if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
                return;

            if (data.Code != Context.Code)
                return;

            lock (_latestHogaLock)
            {
                _latestHogaForAutoTrade = data;
            }

            // 호가 UI는 너무 자주 갱신하지 않는다.
            if ((DateTime.Now - _lastHogaUiUpdateTime).TotalMilliseconds < 300)
                return;

            _lastHogaUiUpdateTime = DateTime.Now;

            Application.Current.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
                        return;

                    if (data.Code != Context.Code)
                        return;

                    AskList.Clear();
                    foreach (var item in data.Asks)
                        AskList.Add(item);

                    BidList.Clear();
                    foreach (var item in data.Bids)
                        BidList.Add(item);

                    TotalAskQty = data.TotalAskQty;
                    TotalBidQty = data.TotalBidQty;
                }));
        }
        private void SubscribeMarketApiEvents()
        {
            if (_marketApi == null)
                return;

            _marketApi.OnLogin += Kiwoom_OnLogin;
            _marketApi.OnLog += Kiwoom_OnLog;
            _marketApi.OnSymbolDetected += Kiwoom_OnSymbolDetected;
            _marketApi.OnAiSymbolDetected += OnAiSymbolDetected;
            _marketApi.OnSymbolDetailUpdated += Kiwoom_OnSymbolDetailUpdated;
            _marketApi.OnBalanceUpdated += Kiwoom_OnBalanceUpdated;
            _marketApi.OnInitialHistoryReceived += Kiwoom_OnInitialHistoryReceived;
            _marketApi.OnTickReceived += Kiwoom_OnTickReceived;
            _marketApi.OnHogaReceived += Kiwoom_OnHogaReceived;
            _marketApi.OnHoldingsReceived += Kiwoom_OnHoldingsReceived;
            _marketApi.OnOrdersReceived += Kiwoom_OnOrdersReceived;
            _marketApi.OnUnfilledOrdersReceived += Kiwoom_OnUnfilledOrdersReceived;
            _marketApi.OnGlobalUpdateRequired += Kiwoom_OnGlobalUpdateRequired;
            _marketApi.OnOrderFilled += Kiwoom_OnOrderFilled;
            _marketApi.OnRealPriceReceived += Kiwoom_OnRealPriceReceived;
            _marketApi.OnInventoryTickReceived += Kiwoom_OnInventoryTickReceived;
            _marketApi.OnMinuteHistoryReceived += Kiwoom_OnMinuteHistoryReceived;
            _marketApi.OnRecentTicksReceived += Kiwoom_OnRecentTicksReceived;
            _marketApi.OnMarketIndexReceived += Kiwoom_OnMarketIndexReceived;
        }

        private void UnsubscribeMarketApiEvents()
        {
            if (_marketApi == null)
                return;

            _marketApi.OnLogin -= Kiwoom_OnLogin;
            _marketApi.OnLog -= Kiwoom_OnLog;
            _marketApi.OnSymbolDetected -= Kiwoom_OnSymbolDetected;
            _marketApi.OnAiSymbolDetected -= OnAiSymbolDetected;
            _marketApi.OnSymbolDetailUpdated -= Kiwoom_OnSymbolDetailUpdated;
            _marketApi.OnBalanceUpdated -= Kiwoom_OnBalanceUpdated;
            _marketApi.OnInitialHistoryReceived -= Kiwoom_OnInitialHistoryReceived;
            _marketApi.OnTickReceived -= Kiwoom_OnTickReceived;
            _marketApi.OnHogaReceived -= Kiwoom_OnHogaReceived;
            _marketApi.OnHoldingsReceived -= Kiwoom_OnHoldingsReceived;
            _marketApi.OnOrdersReceived -= Kiwoom_OnOrdersReceived;
            _marketApi.OnUnfilledOrdersReceived -= Kiwoom_OnUnfilledOrdersReceived;
            _marketApi.OnGlobalUpdateRequired -= Kiwoom_OnGlobalUpdateRequired;
            _marketApi.OnOrderFilled -= Kiwoom_OnOrderFilled;
            _marketApi.OnRealPriceReceived -= Kiwoom_OnRealPriceReceived;
            _marketApi.OnInventoryTickReceived -= Kiwoom_OnInventoryTickReceived;
            _marketApi.OnMinuteHistoryReceived -= Kiwoom_OnMinuteHistoryReceived;
            _marketApi.OnRecentTicksReceived -= Kiwoom_OnRecentTicksReceived;
            _marketApi.OnMarketIndexReceived -= Kiwoom_OnMarketIndexReceived;
        }

        private void DisposeAutoTradeController()
        {
            if (_autoTradeController == null)
                return;

            _autoTradeController.AnalysisEvaluated -= OnAutoTradeAnalysisEvaluated;
            _autoTradeController.OrderRequested -= OnAutoTradeOrderRequested;
            _autoTradeController.Log -= AddAutoTradeAnalysisLog;
            _autoTradeController.Dispose();
            _autoTradeController = null;
        }

        private void FlushDbOnClose()
        {
            try
            {
                _performanceRefreshTimer.Stop();
                _performanceRefreshTimer.Tick -= PerformanceRefreshTimer_Tick;

                Db?.FlushAllPending();
                Db?.BuildAndSaveDailyPerformance(DateTime.Today);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[창 종료 Flush 실패] {ex.Message}");
            }
        }

        public MainWindowViewModel(IMarketApiService marketApi)
        {
            _marketApi = marketApi ?? throw new ArgumentNullException(nameof(marketApi));
            
            SubscribeMarketApiEvents();

            ScreenNo = _marketApi.GetScreenNo();

            ConnectCommand = new RelayCommand(async _ => await ExecuteConnect());
            SearchCommand = new RelayCommand(_ => ExecuteSearch());
            AiToggleCommand = new RelayCommand(OpenNewWindow);

            AutoTradingToggleCommand = new RelayCommand(() =>
            {
                IsAutoTradingEnabled = !IsAutoTradingEnabled;
            });

            InitializeAutoTrading();
            StartPerformanceMonitor();
        }
        // 1. 로그 처리
        private void Kiwoom_OnLog(string wId, string msg)
        {
            if (wId == this.WindowId || wId == "SYSTEM" || wId == "COMMON")
            {
                AddLog(msg);
            }
        }
        // 2. 종목 검출 처리
        private void Kiwoom_OnSymbolDetected(string wId, string code, string name)
        {
            OnSymbolDetected(wId, code, name);
        }
        // 3. 종목 상세 정보 업데이트 (가장 무거운 로직)
        private void Kiwoom_OnSymbolDetailUpdated(string wId, Symbol updatedSymbol)
        {
            if (wId != this.WindowId) return;

            // Dispatcher 밖에서 미리 계산
            double lastPriceNum = 0;
            double.TryParse(updatedSymbol.LastPrice.Replace(",", ""), out lastPriceNum);

            Application.Current.Dispatcher.BeginInvoke(new Action(() =>
            {
                var target = SearchResults.FirstOrDefault(s => s.Code == updatedSymbol.Code);
                if (target != null)
                {
                    target.LastPrice = updatedSymbol.LastPrice;
                    target.Change = updatedSymbol.Change;
                }

                if (updatedSymbol.Code == Context.Code)
                {
                    Context.LastPrice = lastPriceNum;
                }
            }));
        }
        public void HandleAlreadyLoggedIn()
        {
            Kiwoom_OnLogin(true);
        }
        private bool _isInitialized = false; // 중복 실행 방지 플래그

        private void Kiwoom_OnLogin(bool success)
        {
            if (!success) { AddLog("❌ 로그인 실패"); return; }

            if (_isInitialized) return;

            _isInitialized = true;
            AddLog("🔑 로그인 세션 확인 완료");
            FetchAccountList();
            _marketApi.RegisterMarketIndexRealtime(this.WindowId);
        }

        private string _marketTrendText = "-";

        public string MarketTrendText
        {
            get => _marketTrendText;
            set => SetProperty(ref _marketTrendText, value);
        }

        private void Kiwoom_OnMarketIndexReceived(MarketIndexInfo index)
        {
            if (index == null || string.IsNullOrWhiteSpace(index.Code))
                return;

            Application.Current.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (index.Code == "001")
                        Kospi = index;
                    else if (index.Code == "101")
                        Kosdaq = index;
                    else
                        return;

                    var environment = MarketEnvironmentEvaluator.Create(Kospi, Kosdaq);

                    MarketTrendText = environment.Description;

                    _autoTradeController?.UpdateMarketEnvironment(environment);

                    string trendKey =
                        $"{environment.Trend}_{environment.AverageChangeRate:F1}_{environment.MarketRiskScore:F0}_{environment.MarketSupportScore:F0}";

                    bool shouldLog =
                        trendKey != _lastMarketAnalysisLogKey ||
                        (DateTime.Now - _lastMarketAnalysisLogTime).TotalSeconds >= 30;

                    if (!shouldLog)
                        return;

                    _lastMarketAnalysisLogKey = trendKey;
                    _lastMarketAnalysisLogTime = DateTime.Now;

                    AddAutoTradeAnalysisLog(
                        $"[시장분석] " +
                        $"상태={environment.Trend} | " +
                        $"KOSPI={environment.KospiChangeRate:F2}% | " +
                        $"KOSDAQ={environment.KosdaqChangeRate:F2}% | " +
                        $"시장평균={environment.AverageChangeRate:F2}% | " +
                        $"위험={environment.MarketRiskScore:F0} | " +
                        $"지지={environment.MarketSupportScore:F0} | " +
                        $"진입점수보정={environment.EntryScoreAdjustment:+0;-0;0} | " +
                        $"수량배율={environment.PositionSizeMultiplier:F2} | " +
                        $"손절배율={environment.StopLossMultiplier:F2} | " +
                        $"익절배율={environment.TakeProfitMultiplier:F2} | " +
                        $"트레일링배율={environment.TrailingMultiplier:F2}");
                }));
        }
        // Dispose 메서드나 Window_Closing 이벤트에서 호출할 함수
        public void Cleanup()
        {
            DisposeAutoTradeController();
            UnsubscribeMarketApiEvents();
        }

        private void OpenNewWindow()
        {
            // 1. 새 창 객체 생성
            MainWindow newWindow = new MainWindow();

            // 2. 창 크기 및 위치 설정 (1920x1080)
            newWindow.Width = 1920;
            newWindow.Height = 1080;
            newWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            // 제목에 번호를 붙여주면 7800X3D가 관리하기 더 편하겠지?
            newWindow.Title = $"MoneyCreator - 새 작업창 ({DateTime.Now:HH:mm:ss})";

            // 4. 창 표시
            newWindow.Show();
        }
        public void UpdateSearchResults(string query)
        {
            SearchResults.Clear();

            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
            {
                IsSearchPopupOpen = false;
                return;
            }

            var all = _marketApi.GetTotalSymbolList();
            if (all == null || all.Count == 0)
            {
                IsSearchPopupOpen = false;
                return;
            }

            int added = 0;

            foreach (var s in all)
            {
                if (s == null || string.IsNullOrWhiteSpace(s.Name))
                    continue;

                if (!s.Name.Contains(query))
                    continue;

                SearchResults.Add(s);

                if (++added >= 10)
                    break;
            }

            bool shouldOpen = SearchResults.Count > 0;

            Application.Current.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    IsSearchPopupOpen = shouldOpen;
                }),
                DispatcherPriority.Background);
        }
        public void LoadConfig()
        {
            string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.enc");
            if (System.IO.File.Exists(path))
            {
                // SecurityHelper 구현체 필요
                // this.AccountPassword = SecurityHelper.LoadDecryptedPassword(path);
                AddLog("🔐 암호화된 설정 파일을 로드했습니다.");
            }
            else
            {
                AddLog("⚠️ 설정 파일(config.enc)이 없습니다.");
            }
        }
        public bool IsConnected()
        {
            if (_api == null) return false;

            // GetConnectState() 리턴값: 0(미연결), 1(연결완료)
            return _api.GetConnectState() == 1;
        }
        public void AddLog(string msg)
        {
            try
            {
                Application.Current?.Dispatcher.BeginInvoke(new Action(() =>
                {
                    Logs.Insert(0, $"[{DateTime.Now:HH:mm:ss}] {msg}");
                    if (Logs.Count > 100) Logs.RemoveAt(100);
                }));
            }
            catch { }
        }
        private DateTime _lastAnalysisLogTime = DateTime.MinValue;
        private const int MaxAutoTradeAnalysisLogCount = 30;

        public void AddAutoTradeAnalysisLog(string msg)
        {
            if (string.IsNullOrWhiteSpace(msg))
                return;

            bool isTickAnalysis = msg.StartsWith("[틱분석]");
            bool isTradeSignal =
                msg.Contains("판단=Buy") ||
                msg.Contains("판단=Sell") ||
                msg.Contains("Action=Buy") ||
                msg.Contains("Action=Sell");

            if (!isTickAnalysis && !isTradeSignal)
            {
                if ((DateTime.Now - _lastAnalysisLogTime).TotalMilliseconds < 500)
                    return;

                _lastAnalysisLogTime = DateTime.Now;
            }

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    UpdateTradeAnalysisCardFromLog(msg);

                    AutoTradeAnalysisLogs.Insert(0, msg);

                    while (AutoTradeAnalysisLogs.Count > MaxAutoTradeAnalysisLogCount)
                        AutoTradeAnalysisLogs.RemoveAt(AutoTradeAnalysisLogs.Count - 1);
                }));
        }
        public async Task ExecuteConnect()
        {
            AddLog("🛠️ 키움 API 연결 프로세스...");
            await Task.Run(() =>
            {
                ProcessStartInfo startInfo = new ProcessStartInfo { FileName = @"D:\OpenAPI\opstarter.exe", UseShellExecute = true, Verb = "runas" };
                using (var p = Process.Start(startInfo)) { p?.WaitForExit(); }
            });
            _marketApi.Login();
        }
        private void ExecuteSearch() { }
        // [수정] OnSymbolDetected 메서드 시그니처 변경 및 로직 유지
        private void OnSymbolDetected(string windowId, string code, string name)
        {
            // 특정 창에서 요청한 조건검색 결과라면 windowId 체크가 필요할 수 있음
            // 현재는 모든 검색 결과를 화면에 표시하는 로직이므로 인자만 맞춰둠
            Application.Current?.Dispatcher.Invoke(() =>
            {
                if (!Symbols.Any(s => s.Code == code))
                    Symbols.Insert(0, new Symbol { Code = code, Name = name, LastPrice = "수집중" });
            });
        }
        private void OnAiSymbolDetected(string code, string name, string strength)
        {
            Application.Current?.Dispatcher.Invoke(() =>
            {
                AiSelectedSymbols.Add(new AiResult { Code = code, Name = name, Reason = strength });
            });
        }
        public void Dispose()
        {
            FlushDbOnClose();
            Cleanup();

            _marketApi?.UnregisterWindow(WindowId);

            if (Context != null && !string.IsNullOrWhiteSpace(Context.Code))
            {
                string key = $"{WindowId}_{Context.Code}";
                _requestTokens.TryRemove(key, out _);
            }
        }
    }
}
