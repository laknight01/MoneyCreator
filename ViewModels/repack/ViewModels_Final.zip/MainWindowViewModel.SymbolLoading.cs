﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private HoldingInfo _selectedHolding;
        public HoldingInfo SelectedHolding
        {
            get => _selectedHolding;
            set
            {
                if (SetProperty(ref _selectedHolding, value) && value != null)
                {
                    // 선택된 보유 종목의 코드를 이용해 종목 변경 실행
                    // Holding 클래스에 종목 코드(Code) 속성이 있다고 가정함
                    ExecuteSymbolChange(value.Code, value.Name);
                }
            }
        }
        private async void ExecuteSymbolChange(string code, string name)
        {
            if (string.IsNullOrWhiteSpace(code))
                return;

            var symbol = new Symbol
            {
                Code = code,
                Name = name
            };

            await LoadSymbolDataAsync(symbol);
        }
        private bool FocusOpenedSymbolWindow(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return false;

            foreach (Window w in Application.Current.Windows)
            {
                if (w.DataContext is MainWindowViewModel vm)
                {
                    // 현재 창 자신
                    if (w == this.HostWindow)
                    {
                        // 현재 창이 이미 이 종목을 보고 있을 때만 중복 처리
                        if (vm.Context.Code == code)
                        {
                            AddLog($"ℹ️ 현재 창에서 이미 열린 종목: {code}");
                            return true;
                        }

                        continue;
                    }

                    // 다른 창은 Tag 또는 Context.Code로 판단
                    if ((w.Tag as string) == code || vm.Context.Code == code)
                    {
                        if (w.WindowState == WindowState.Minimized)
                            w.WindowState = WindowState.Normal;

                        w.Activate();
                        w.Focus();

                        AddLog($"🔎 이미 열린 종목 창으로 이동: {code}");
                        return true;
                    }
                }
            }

            return false;
        }
        public ObservableCollection<Symbol> SearchResults { get; } = new ObservableCollection<Symbol>();
        private Symbol _selectedSearchSymbol;
        public Symbol SelectedSearchSymbol
        {
            get => _selectedSearchSymbol;
            set
            {
                if (_selectedSearchSymbol == value) return; // 불필요한 중복 호출 방지[cite: 3]
                _selectedSearchSymbol = value;
                OnPropertyChanged();

                if (value != null)
                {
                    _ = LoadSymbolDataAsync(value); // 비동기로 태움
                }
            }
        }
        // 1. 핵심 로직을 별도 메서드로 추출
        public async Task LoadSymbolDataAsync(Symbol symbol, bool waitHoldingLoad = true)
        {
            if (symbol == null)
                return;

            if (FocusOpenedSymbolWindow(symbol.Code))
                return;

            string previousCode = Context == null ? string.Empty : Context.Code;

            IsLoading = true;
            await Task.Yield();

            // 종목 변경 시작 시 이전 종목 자동매매 상태부터 차단
            if (!string.IsNullOrWhiteSpace(previousCode) && previousCode != symbol.Code)
            {
                MarkAutoTradeDataNotReady(previousCode);
                _autoTradeController?.Reset(previousCode);

                AddAutoTradeAnalysisLog(
                    $"[자동매매] 종목 변경 감지 - 이전 종목 상태 초기화: {previousCode} → {symbol.Code}");
            }

            ClearBuffer();
            OnChartResetRequired?.Invoke();

            double price = 0;
            double.TryParse(symbol.LastPrice, out price);

            Context.SwitchSymbol(symbol.Code, symbol.Name, price);

            // 새 종목은 분봉 바인딩 완료 전까지 자동매매 차단
            MarkAutoTradeDataNotReady(symbol.Code);
            _autoTradeController?.Reset(symbol.Code);

            ResetRealtimeTickWindow();
            _minuteHistoryBuffer.Clear();

            CheckHoldingStatus();

            _marketApi.ReplaceSubscription(this.WindowId, ScreenNo, symbol.Code);

            var holding = AccountHoldings?.FirstOrDefault(h => h.Code == symbol.Code);

            if (holding != null)
            {
                var store = GlobalHoldingStore.GetOrCreate(holding.Code, holding.Name);

                bool hasMinuteData;
                bool isLoading;

                lock (store.SyncRoot)
                {
                    hasMinuteData =
                        store.MinuteList.Count > 0 ||
                        store.IsMinuteHistoryLoaded ||
                        store.IsHistoryLoaded;

                    isLoading = store.IsLoadingHistory;
                }

                if (!hasMinuteData && !isLoading)
                    RequestHoldingHistoryAndRealtime(holding);

                if (hasMinuteData)
                {
                    BindHoldingStoreToChart(store, symbol);

                    IsLoading = false;
                    IsSearchPopupOpen = false;

                    AddLog($"📊 보유주 저장 데이터 바인딩: {symbol.Name}({symbol.Code})");
                    return;
                }

                if (waitHoldingLoad && isLoading)
                {
                    AddLog($"⏳ 보유주 데이터 로딩 대기: {symbol.Name}({symbol.Code})");

                    await store.HistoryLoadedSource.Task;

                    if (store.IsHistoryLoaded)
                    {
                        BindHoldingStoreToChart(store, symbol);

                        IsLoading = false;
                        IsSearchPopupOpen = false;

                        AddLog($"📊 보유주 로딩 완료 후 바인딩: {symbol.Name}({symbol.Code})");
                        return;
                    }
                }

                _ = BindHoldingStoreWhenLoadedAsync(store, symbol);

                IsLoading = false;
                IsSearchPopupOpen = false;

                AddLog($"⏳ 현재창 보유주 데이터 로딩 중: {symbol.Name}({symbol.Code})");
                return;
            }

            _marketApi.RequestMinuteCandles(
                this.WindowId,
                symbol.Code,
                ScreenNo,
                daysToLoad: 2,
                maxRows: 0,
                priority: 0);

            IsSearchPopupOpen = false;
            AddLog($"✅ 현재창 일반 종목 분봉 요청: {symbol.Name}({symbol.Code})");
        }
        private async Task BindHoldingStoreWhenLoadedAsync(HoldingSymbolContext store, Symbol symbol)
        {
            try
            {
                await store.HistoryLoadedSource.Task;

                Application.Current.Dispatcher.Invoke(() =>
                {
                    if (Context.Code != symbol.Code)
                        return;

                    if (store.IsHistoryLoaded)
                        BindHoldingStoreToChart(store, symbol);

                    IsLoading = false;
                });
            }
            catch
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    IsLoading = false;
                });
            }
        }
        // ============================================================
        // [교체] BindHoldingStoreToChart 전체 교체
        // 보유주 차트도 이제 실시간틱이 아니라 저장된 분봉만 사용
        // ============================================================
        private void BindHoldingStoreToChart(HoldingSymbolContext store, Symbol symbol)
        {
            if (store == null || symbol == null)
                return;

            List<TrackedSymbol> chartData;
            TrackedSymbol lastMinute = null;
            TrackedSymbol lastTick = null;

            lock (store.SyncRoot)
            {
                chartData = GetChartMinuteData(store.MinuteList);

                if (chartData.Count > 0)
                    lastMinute = chartData[chartData.Count - 1];

                if (store.RecentTickList.Count > 0)
                    lastTick = store.RecentTickList[store.RecentTickList.Count - 1];
            }

            var last = lastTick ?? lastMinute;

            if (last != null)
            {
                Context.LastPrice = last.LastPrice;
                Price = last.LastPrice;
                OrderPrice = last.LastPrice;
            }

            _minuteTickBuffer.Clear();

            if (chartData.Count > 0)
            {
                _lastChartMinute = chartData[chartData.Count - 1].LastUpdated;
                _currentMinute = _lastChartMinute;

                Context.SymbolList.Clear();
                Context.SymbolList.AddRange(chartData);

                RequestChartRefresh?.Invoke(CreateChartPayload(chartData, isFullRefresh: true));
            }

            _isHistoryBindingComplete = true;
            MarkAutoTradeDataReady(symbol.Code);
            IsLoading = false;

            AddLog($"📊 보유주 분봉 차트 표시: {symbol.Name}({symbol.Code}) / 분봉 {chartData.Count}개 / 최근틱 {store.RecentTickList.Count}개");
        }
        // 보유 여부를 새로고침하는 핵심 메소드
        public void CheckHoldingStatus()
        {
            // UI 스레드에서 안전하게 실행
            App.Current.Dispatcher.Invoke(() =>
            {
                if (AccountHoldings == null || string.IsNullOrEmpty(Context.Code))
                {
                    Context.CurrentHold = null;
                    HoldingQty = 0;
                    return;
                }

                // 현재 선택된 종목(Context.Code)과 일치하는 보유 정보 탐색[cite: 2]
                var holding = AccountHoldings.FirstOrDefault(h => h.Code == Context.Code);

                if (holding != null)
                {
                    Context.CurrentHold = holding;
                    // 모델의 Quantity를 ViewModel의 HoldingQty에 동기화
                    this.HoldingQty = holding.Quantity;
                }
                else
                {
                    Context.CurrentHold = null;
                    this.HoldingQty = 0;
                }
            });
        }
        public void ClearBuffer()
        {
            Symbols.Clear();
            AskList.Clear();
            BidList.Clear();

            _realTimeBuffer.Clear();
            _minuteTickBuffer.Clear();

            _isHistoryBindingComplete = false;

            Context.Reset();
        }
        private async Task ExecuteOpenAllHoldings()
        {
            if (AccountHoldings == null || AccountHoldings.Count == 0)
            {
                AddLog("⚠️ 조회된 보유 종목이 없어. 계좌 조회를 먼저 해줘.");
                return;
            }

            bool currentWindowUsed = !string.IsNullOrWhiteSpace(Context.Code);

            foreach (var holding in AccountHoldings.ToList())
            {
                bool isAlreadyOpen = Application.Current.Windows
                    .Cast<Window>()
                    .Any(w =>
                    {
                        if (w.DataContext is MainWindowViewModel vm)
                            return vm.Context.Code == holding.Code;

                        return (w.Tag as string) == holding.Code;
                    });

                AddLog($"[창오픈검사] {holding.Name}({holding.Code}) / already={isAlreadyOpen}");

                // 중요:
                // OpenAllHoldings에서는 이미 열린 종목으로 포커스하지 않고 그냥 건너뜀
                if (isAlreadyOpen)
                    continue;

                var symbol = new Symbol
                {
                    Code = holding.Code,
                    Name = holding.Name,
                    LastPrice = holding.CurrentPrice.ToString()
                };

                if (!currentWindowUsed)
                {
                    if (HostWindow != null)
                    {
                        HostWindow.Tag = holding.Code;
                        HostWindow.Title = $"[K-Nest] {holding.Name} ({holding.Code})";
                    }

                    Context.CurrentHold = holding;

                    // 중요:
                    // 중복창 포커스 로직을 피해야 하므로 전용 메서드 사용 권장
                    await LoadSymbolDataAsync(symbol, waitHoldingLoad: false);

                    currentWindowUsed = true;

                    AddLog($"✅ 현재 창에 미오픈 보유 종목 로딩: {holding.Name}({holding.Code})");
                }
                else
                {
                    await OpenStockWindow(holding);
                    AddLog($"✅ 새 창에 미오픈 보유 종목 로딩: {holding.Name}({holding.Code})");
                }

                await Task.Delay(200);
            }

            AddLog("✅ 모든 보유 종목 창 오픈 프로세스 완료.");
        }
        public async Task OpenStockWindow(HoldingInfo holding)
        {
            if (holding == null)
                return;

            MainWindow newWindow = new MainWindow();
            newWindow.Tag = holding.Code;

            if (newWindow.DataContext is MainWindowViewModel targetVm)
            {
                targetVm.ScreenNo = _marketApi.GetScreenNo();

                targetVm.ApplyParentAccountContext(
                    SelectedAccount,
                    CurrentBalance,
                    AccountHoldings,
                    OrderHistory);

                targetVm.Context.CurrentHold = holding;

                newWindow.Title = $"[K-Nest] {holding.Name} ({holding.Code})";
                newWindow.Show();

                await Task.Delay(500);

                var symbol = new Symbol
                {
                    Code = holding.Code,
                    Name = holding.Name,
                    LastPrice = holding.CurrentPrice.ToString()
                };

                await targetVm.LoadSymbolDataAsync(symbol, waitHoldingLoad: false);
                IsMainLoading = false;
                AddLog($"✅ 보유 종목 창 오픈 완료: {holding.Name}({holding.Code})");
            }
            else
            {
                newWindow.Close();
            }
        }
        // MainWindowViewModel.cs 내부 수정
        private void Kiwoom_OnInitialHistoryReceived(string windowId, List<TrackedSymbol> history, bool islast)
        {
            // 보유주 백그라운드 과거데이터
            if (!string.IsNullOrEmpty(windowId) && windowId.StartsWith("INV:"))
            {
                HandleHoldingHistory(windowId, history, islast);
                return;
            }

            // 일반 창 전용 과거데이터
            if (this.WindowId != windowId)
                return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                OnInitialHistoryReceived_Handler(history, islast);
            });
        }
        private void HandleHoldingHistory(string windowId, List<TrackedSymbol> history, bool islast)
        {
            string code = windowId.Replace("INV:", "");
            var store = GlobalHoldingStore.GetOrCreate(code);

            lock (store.SyncRoot)
            {
                int receivedCount = history == null ? 0 : history.Count;

                if (history != null && history.Count > 0)
                {
                    foreach (var tick in history)
                        store.SymbolList.Add(tick);
                }

                //Debug.WriteLine(
                //    $"✅ 보유주 과거데이터 종목코드[{code}] 수신 {receivedCount}개 / 총 {store.SymbolList.Count}개 / islast={islast}"
                //);

                if (!islast)
                    return;

                // 키움 과거데이터는 보통 최신 → 과거 순서
                // 전체 정렬 대신 한 번만 뒤집어서 과거 → 최신 순서로 만든다
                store.SymbolList.Reverse();

                if (store.SymbolList.Count > 0)
                    store.LastTickTime = store.SymbolList[store.SymbolList.Count - 1].LastUpdated;

                while (store.PendingTicks.Count > 0)
                {
                    var pending = store.PendingTicks.Dequeue();

                    if (pending.LastUpdated < store.LastTickTime)
                        continue;

                    store.SymbolList.Add(pending);

                    if (pending.LastUpdated > store.LastTickTime)
                        store.LastTickTime = pending.LastUpdated;
                }

                // 분봉도 여기서 한 번만 생성
                store.MinuteList.Clear();
                store.MinuteList.AddRange(AggregateToMinuteBars(store.SymbolList));

                store.IsHistoryLoaded = true;
                store.IsLoadingHistory = false;
                store.HistoryLoadedSource.TrySetResult(true);
            }

            Application.Current.Dispatcher.Invoke(() =>
            {
                var holding = AccountHoldings.FirstOrDefault(x => x.Code == code);

                if (holding != null)
                {
                    holding.IsHistoryLoading = false;
                    holding.IsHistoryLoaded = true;
                }
            });

            AddLog($"✅ 보유주 과거데이터 저장 완료: {code}");
        }
        private void UpdateAutoTradePositionsFromHoldings(List<HoldingInfo> holdings)
        {
            foreach (var holding in holdings)
            {
                if (holding == null || string.IsNullOrWhiteSpace(holding.Code))
                    continue;

                _autoTradeController?.UpdatePosition(
                    holding.Code,
                    holding.Quantity,
                    holding.EntryPrice);
            }
        }

        private void ApplyHoldingsToUi(List<HoldingInfo> holdings)
        {
            AccountHoldings.Clear();

            foreach (var holding in holdings)
            {
                if (holding == null || string.IsNullOrWhiteSpace(holding.Code))
                    continue;

                var store = GlobalHoldingStore.GetOrCreate(holding.Code, holding.Name);

                holding.IsHistoryLoaded = store.IsHistoryLoaded;
                holding.IsHistoryLoading = store.IsLoadingHistory;

                AccountHoldings.Add(holding);
            }

            if (Context != null && !string.IsNullOrWhiteSpace(Context.Code))
            {
                var currentHolding = AccountHoldings.FirstOrDefault(x => x.Code == Context.Code);

                Context.CurrentHold = currentHolding;
                HoldingQty = currentHolding != null ? currentHolding.Quantity : 0;

                _autoTradeController?.UpdatePosition(
                    Context.Code,
                    HoldingQty,
                    currentHolding == null ? 0 : currentHolding.EntryPrice);
            }
            else
            {
                HoldingQty = 0;
            }
        }

        private void Kiwoom_OnHoldingsReceived(string windowId, List<HoldingInfo> holdings)
        {
            if (holdings == null)
                return;

            UpdateAutoTradePositionsFromHoldings(holdings);

            Application.Current.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    ApplyHoldingsToUi(holdings);
                }));

            CompleteInitialMainLoadingToken("HOLDINGS");
            SyncAutoTradeState("잔고 갱신");
        }
    }
}
