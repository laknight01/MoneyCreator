﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        #region 사용자정보
        public ObservableCollection<string> AccountList { get; set; } = new ObservableCollection<string>();
        private string _selectedAccount;
        public string SelectedAccount
        {
            get => _selectedAccount;
            set
            {
                if (_selectedAccount == value)
                    return;

                _selectedAccount = value;
                OnPropertyChanged();

                if (_suppressAccountAutoRefresh)
                    return;

                if (AccountHoldings == null || AccountHoldings.Count == 0)
                {
                    UpdateBalance();
                }
                else
                {
                    AccountHoldings.Clear();
                    UpdateBalance();
                }
            }
        }
        public void ApplyParentAccountContext(
            string accountNo,
            long currentBalance,
            ObservableCollection<HoldingInfo> accountHoldings,
            ObservableCollection<OrderInfo> orderHistory)
        {
            _suppressAccountAutoRefresh = true;

            try
            {
                _selectedAccount = accountNo;
                OnPropertyChanged(nameof(SelectedAccount));

                CurrentBalance = currentBalance;
                AccountHoldings = accountHoldings ?? new ObservableCollection<HoldingInfo>();
                OrderHistory = orderHistory ?? new ObservableCollection<OrderInfo>();

                // CurrentBalance와 OrderHistory가 모두 반영된 뒤 자동매매용 예수금을 계산해야 한다.
                UpdateAutoTradeCash("계좌 컨텍스트 적용");
            }
            finally
            {
                _suppressAccountAutoRefresh = false;
            }
        }

        private bool _suppressAccountAutoRefresh;
        private long _currentBalance;
        public long CurrentBalance
        {
            get => _currentBalance;
            set
            {
                _currentBalance = value;
                OnPropertyChanged(nameof(CurrentBalance));
            }
        }
        private void FetchAccountList()
        {
            if (_api == null)
                return;

            string accList = _api.GetLoginInfo("ACCNO").Trim();

            var accounts = accList
                .Split(';')
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Where(x => x.Length >= 10)
                .Select(x => x.Substring(0, 10))
                .Distinct()
                .ToList();

            Application.Current.Dispatcher.Invoke(() =>
            {
                AccountList.Clear();

                foreach (var account in accounts)
                    AccountList.Add(account);

                SelectedAccount = AccountList.FirstOrDefault();
            });
        }

        private async void UpdateBalance()
        {
            if (_suppressAccountAutoRefresh)
                return;

            if (string.IsNullOrEmpty(SelectedAccount) || _api == null)
                return;

            BeginInitialMainLoading();

            _marketApi.RequestCashInfo(WindowId, SelectedAccount, ScreenNo);

            await Task.Delay(50);

            _marketApi.RequestAccountHoldings(WindowId, SelectedAccount, ScreenNo);

            await Task.Delay(50);

            _marketApi.RequestOrderHistory(WindowId, SelectedAccount, ScreenNo);
        }

        public void UpdateBalanceFromApi(long currentBalance)
        {
            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    CurrentBalance = currentBalance;

                    UpdateAutoTradeCash("예수금 수신");
                }));
        }
        // 4. 잔고 업데이트
        private void Kiwoom_OnBalanceUpdated(string wId, long balance)
        {
            UpdateBalanceFromApi(balance);
            CompleteInitialMainLoadingToken("CASH");
        }
        #endregion

        public void RegisterApi(AxKHOpenAPI api)
        {
            if (api == null)
                return;

            _api = api;
            _marketApi.SetApiInstance(api);
            AddLog("✅ API 인스턴스 등록 완료");
        }
    }
}
