﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private readonly DispatcherTimer _performanceRefreshTimer = new DispatcherTimer();
        private bool _isRefreshingPerformance;
        private DateTime _lastPerformanceBuildTime = DateTime.MinValue;
        public ICommand RefreshCommand => new RelayCommand(_ => UpdateBalance());//잔고조회

        private string _accountPassword;
        private string _tradePerformanceStatusText = "성과 집계 대기";
        public string TradePerformanceStatusText
        {
            get => _tradePerformanceStatusText;
            set { _tradePerformanceStatusText = value; OnPropertyChanged(nameof(TradePerformanceStatusText)); }
        }
        private string _performanceLastUpdatedText = "-";
        public string PerformanceLastUpdatedText
        {
            get => _performanceLastUpdatedText;
            set { _performanceLastUpdatedText = value; OnPropertyChanged(nameof(PerformanceLastUpdatedText)); }
        }
        private int _todayTradeCount;
        public int TodayTradeCount
        {
            get => _todayTradeCount;
            set { _todayTradeCount = value; OnPropertyChanged(nameof(TodayTradeCount)); }
        }
        private int _todayWinCount;
        public int TodayWinCount
        {
            get => _todayWinCount;
            set { _todayWinCount = value; OnPropertyChanged(nameof(TodayWinCount)); }
        }
        private int _todayLossCount;
        public int TodayLossCount
        {
            get => _todayLossCount;
            set { _todayLossCount = value; OnPropertyChanged(nameof(TodayLossCount)); }
        }
        private double _todayWinRate;
        public double TodayWinRate
        {
            get => _todayWinRate;
            set { _todayWinRate = value; OnPropertyChanged(nameof(TodayWinRate)); }
        }
        private double _todayAvgProfitRate;
        public double TodayAvgProfitRate
        {
            get => _todayAvgProfitRate;
            set { _todayAvgProfitRate = value; OnPropertyChanged(nameof(TodayAvgProfitRate)); }
        }
        private double _todayNetProfit;
        public double TodayNetProfit
        {
            get => _todayNetProfit;
            set { _todayNetProfit = value; OnPropertyChanged(nameof(TodayNetProfit)); }
        }
        private double _todayGrossProfit;
        public double TodayGrossProfit
        {
            get => _todayGrossProfit;
            set { _todayGrossProfit = value; OnPropertyChanged(nameof(TodayGrossProfit)); }
        }
        private double _todayGrossLoss;
        public double TodayGrossLoss
        {
            get => _todayGrossLoss;
            set { _todayGrossLoss = value; OnPropertyChanged(nameof(TodayGrossLoss)); }
        }
        private double _todayFeeTax;
        public double TodayFeeTax
        {
            get => _todayFeeTax;
            set { _todayFeeTax = value; OnPropertyChanged(nameof(TodayFeeTax)); }
        }
        private double _todayBestTradeRate;
        public double TodayBestTradeRate
        {
            get => _todayBestTradeRate;
            set { _todayBestTradeRate = value; OnPropertyChanged(nameof(TodayBestTradeRate)); }
        }
        private double _todayWorstTradeRate;
        public double TodayWorstTradeRate
        {
            get => _todayWorstTradeRate;
            set { _todayWorstTradeRate = value; OnPropertyChanged(nameof(TodayWorstTradeRate)); }
        }
        private int _totalTradeCount;
        public int TotalTradeCount
        {
            get => _totalTradeCount;
            set { _totalTradeCount = value; OnPropertyChanged(nameof(TotalTradeCount)); }
        }
        private double _totalNetProfit;
        public double TotalNetProfit
        {
            get => _totalNetProfit;
            set { _totalNetProfit = value; OnPropertyChanged(nameof(TotalNetProfit)); }
        }
        private double _totalWinRate;
        public double TotalWinRate
        {
            get => _totalWinRate;
            set { _totalWinRate = value; OnPropertyChanged(nameof(TotalWinRate)); }
        }
        private double _totalAvgProfitRate;
        public double TotalAvgProfitRate
        {
            get => _totalAvgProfitRate;
            set { _totalAvgProfitRate = value; OnPropertyChanged(nameof(TotalAvgProfitRate)); }
        }
        private async void PerformanceRefreshTimer_Tick(object sender, EventArgs e)
        {
            await RefreshTradePerformanceAsync(forceBuildToday: true);
        }

        private void StartPerformanceMonitor()
        {
            try
            {
                _performanceRefreshTimer.Stop();
                _performanceRefreshTimer.Tick -= PerformanceRefreshTimer_Tick;

                _performanceRefreshTimer.Interval = TimeSpan.FromMinutes(5);
                _performanceRefreshTimer.Tick += PerformanceRefreshTimer_Tick;
                _performanceRefreshTimer.Start();

                _ = Task.Run(async () =>
                {
                    try
                    {
                        Db?.RebuildRecentPerformanceDays(7);

                        await RefreshTradePerformanceAsync(forceBuildToday: true);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine("[성과 미집계 복구 실패] " + ex.Message);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[성과 모니터 시작 실패] " + ex.Message);
            }
        }
        public async Task RefreshTradePerformanceAsync(bool forceBuildToday)
        {
            if (_isRefreshingPerformance)
                return;

            _isRefreshingPerformance = true;

            try
            {
                var result = await Task.Run(() =>
                {
                    if (forceBuildToday)
                    {
                        Db?.BuildAndSaveDailyPerformance(DateTime.Today, rebuildTradeResults: true);
                        _lastPerformanceBuildTime = DateTime.Now;
                    }

                    var today = Db?.GetDailyPerformance(DateTime.Today)
                        ?? Db?.BuildAndSaveDailyPerformance(DateTime.Today, rebuildTradeResults: true);

                    var total = Db?.RebuildAndSaveTotalPerformance();

                    return new
                    {
                        Today = today,
                        Total = total
                    };
                });

                Application.Current?.Dispatcher.Invoke(() =>
                {
                    ApplyPerformanceSnapshot(result.Today, result.Total);
                });
            }
            catch (Exception ex)
            {
                TradePerformanceStatusText = "성과 집계 실패";
                Debug.WriteLine("[성과 갱신 실패] " + ex.Message);
            }
            finally
            {
                _isRefreshingPerformance = false;
            }
        }
        private void ApplyPerformanceSnapshot(DailyPerformanceRecord today, DailyPerformanceRecord total)
        {
            if (today != null)
            {
                TodayTradeCount = today.TradeCount;
                TodayWinCount = today.WinCount;
                TodayLossCount = today.LossCount;
                TodayWinRate = today.WinRate;
                TodayAvgProfitRate = today.AvgProfitRate;
                TodayNetProfit = today.NetProfit;
                TodayGrossProfit = today.GrossProfit;
                TodayGrossLoss = today.GrossLoss;
                TodayFeeTax = today.FeeTax;
                TodayBestTradeRate = today.BestTradeRate;
                TodayWorstTradeRate = today.WorstTradeRate;
                PerformanceLastUpdatedText = today.UpdatedAt == default(DateTime)
                    ? "-"
                    : today.UpdatedAt.ToString("HH:mm:ss");
            }

            if (total != null)
            {
                TotalTradeCount = total.TradeCount;
                TotalNetProfit = total.NetProfit;
                TotalWinRate = total.WinRate;
                TotalAvgProfitRate = total.AvgProfitRate;
            }

            TradePerformanceStatusText = "성과 집계 정상";
        }
    }
}
