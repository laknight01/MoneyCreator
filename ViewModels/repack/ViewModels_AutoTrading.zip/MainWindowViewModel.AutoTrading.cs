﻿using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private AutoTradeCoreWorker _autoTradeController;

        // 자동매매 분석 가능 상태
        // - 종목 전환/과거분봉 로딩 중에는 자동매매가 분봉 리스트를 읽지 않게 막는다.
        // - 자동매매 ON 상태에서 새창/새종목 검색 시 차트/분봉 데이터가 교체되는 중 분석이 먼저 도는 문제 방지.
        private volatile bool _isAutoTradeDataReady = false;
        private string _autoTradeReadyCode = string.Empty;
        private DateTime _lastAutoTradeEnqueueTime = DateTime.MinValue;
        private readonly ConcurrentDictionary<string, DateTime> _lastFeatureSnapshotSavedAtByCode =
            new ConcurrentDictionary<string, DateTime>();

        private const int AutoTradeTickEnqueueIntervalMs = 300;

        private readonly ConcurrentDictionary<string, bool> _autoCancelWatchMap =
            new ConcurrentDictionary<string, bool>();

        private readonly AutoTradeSettings _autoTradeSettings = new AutoTradeSettings
        {
            UseMlNet = true,
            UseFullCashSizingForTest = false,
            UsePartialTakeProfitSell = false,
            UsePortfolioCashSizing = true,
            UseDynamicMarketThresholds = true,

            MaxPortfolioCashUseRatio = 0.80,
            MaxCashRatioPerSymbol = 0.25,
            MaxScorePositionMultiplier = 1.5,
            MinOrderAmount = 30000,

            Enabled = false,
            DryRun = true,
            UseAi = false,
            AllowBuy = true,
            AllowSell = true,

            AllowAdditionalBuy = true,
            MaxAdditionalBuyCountPerCode = 2,
            AdditionalBuyMinProfitRate = -1.5,
            AdditionalBuyMaxProfitRate = 2.0,
            AdditionalBuyCashRatio = 0.15,
            AdditionalBuyPositionRatio = 0.5,

            DefaultOrderQty = 1,
            MaxOrderAmount = 100000,
            MaxPositionAmount = 300000,
            MaxTotalPositionAmount = 1000000,
            MinCashRemain = 30000,

            MinSignalScore = 70,
            CooldownSeconds = 20,
            AiModelFilter = "llama-3-8b",
            HogaType = "00",
            StopLossRate = 1.0,
            TakeProfitRate = 999,
            TrailingStartProfitRate = 999,
            TrailingStopRate = 999,
            AnalysisLogMode = AutoTradeAnalysisLogMode.All
        };

        private string _tirexPredictionText = "TiRex 대기";
        public string TiRexPredictionText
        {
            get => _tirexPredictionText;
            set => SetProperty(ref _tirexPredictionText, value);
        }

        private string _tirexPredictionDetail = "-";
        public string TiRexPredictionDetail
        {
            get => _tirexPredictionDetail;
            set => SetProperty(ref _tirexPredictionDetail, value);
        }

        public bool IsAutoTradingEnabled
        {
            get => _autoTradeSettings.Enabled;
            set
            {
                if (_autoTradeSettings.Enabled == value)
                    return;

                _autoTradeSettings.Enabled = value;
                OnPropertyChanged();

                _autoTradeController?.UpdateSettings(_autoTradeSettings);

                if (value)
                    StartAutoTradingForCurrentSymbol();
                else
                    StopAutoTradingForCurrentSymbol();
            }
        }

        private void InitializeAutoTrading()
        {
            if (_autoTradeController != null)
                return;

            var mlFilter = new TiRexHttpSignalFilter(
                "http://127.0.0.1:5001/predict",
                AddAutoTradeAnalysisLog,
                UpdateTiRexPredictionUi);

            _autoTradeController = new AutoTradeCoreWorker(
                _autoTradeSettings,
                mlFilter,
                () => WindowId,
                () => ScreenNo,
                () => SelectedAccount,
                GetActiveAutoTradeSlotCount);

            _autoTradeController.AnalysisEvaluated += OnAutoTradeAnalysisEvaluated;
            _autoTradeController.OrderRequested += OnAutoTradeOrderRequested;
            _autoTradeController.Log += AddAutoTradeAnalysisLog;

            SyncAutoTradeState("자동매매 초기화");
            _autoTradeController.Start();
        }

        private void StartAutoTradingForCurrentSymbol()
        {
            AddLog("🤖 자동매매 ON");
            AddAutoTradeAnalysisLog("🤖 자동매매 ON - 기존 분봉/최근틱 기준 분석 준비");

            if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
                return;

            SeedAutoTradeHistory(Context.Code);
            SyncAutoTradeState("자동매매 ON");
        }

        private void StopAutoTradingForCurrentSymbol()
        {
            _autoTradeController?.Reset(Context?.Code);

            AddLog("🤖 자동매매 OFF");
            AddAutoTradeAnalysisLog("🤖 자동매매 OFF - 대기중 주문/분석 상태 초기화");
        }

        private void UpdateTiRexPredictionUi(TiRexPredictionResult result)
        {
            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (result == null)
                    {
                        TiRexPredictionText = "TiRex 대기";
                        TiRexPredictionDetail = "-";
                        return;
                    }

                    TiRexPredictionText =
                        result.Direction == TiRexDirection.Up ? "TiRex 상승 예측" :
                        result.Direction == TiRexDirection.Down ? "TiRex 하락 예측" :
                        result.Direction == TiRexDirection.Flat ? "TiRex 횡보 예측" :
                        "TiRex 불확실";

                    TiRexPredictionDetail =
                        $"수익예측 {result.PredictedReturn:+0.00;-0.00;0.00}% / 신뢰 {result.Confidence:P0}";
                }));
        }
    }
}
