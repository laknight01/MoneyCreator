﻿using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void SyncAutoTradeState(string reason = null)
        {
            try
            {
                if (_autoTradeController == null)
                    return;

                _autoTradeController.UpdateCash(GetAutoTradeAvailableCash());
                _autoTradeController.UpdateOpenOrders(GetOpenOrdersForAutoTrade());

                SyncAutoTradePosition(Context?.Code);

                if (!string.IsNullOrWhiteSpace(reason))
                    AddAutoTradeAnalysisLog($"[Core동기화] {reason}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[AutoTradeCore 상태 동기화 실패] " + ex.Message);
            }
        }

        private long GetAutoTradeAvailableCash()
        {
            try
            {
                long available = CurrentBalance - GetPendingBuyAmount();

                return available < 0
                    ? 0
                    : available;
            }
            catch
            {
                return Math.Max(0, CurrentBalance);
            }
        }

        private long GetPendingBuyAmount()
        {
            if (OrderHistory == null)
                return 0;

            long amount = 0;

            foreach (var order in OrderHistory)
            {
                if (!IsPendingBuyOrder(order))
                    continue;

                double price = order.Price > 0
                    ? order.Price
                    : order.ExecPrice;

                if (price <= 0)
                    continue;

                amount += (long)(price * order.UntradedQty);
            }

            return amount;
        }

        private static bool IsPendingBuyOrder(OrderInfo order)
        {
            return order != null &&
                   order.UntradedQty > 0 &&
                   !string.IsNullOrWhiteSpace(order.OrderType) &&
                   order.OrderType.Contains("매수");
        }

        // 외부 Account/Orders partial에서 호출할 수 있으므로 유지.
        // Core로 들어가는 Cash의 단일 통로다.
        private void UpdateAutoTradeCash(string reason = null)
        {
            try
            {
                if (_autoTradeController == null)
                    return;

                long availableCash = GetAutoTradeAvailableCash();
                _autoTradeController.UpdateCash(availableCash);

                if (!string.IsNullOrWhiteSpace(reason))
                {
                    AddAutoTradeAnalysisLog(
                        $"[자동매매 예수금] {reason} / " +
                        $"키움={CurrentBalance:N0} / " +
                        $"자동매매사용가능={availableCash:N0}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[자동매매 예수금 동기화 실패] " + ex.Message);
            }
        }

        private void SyncAutoTradePosition(string code)
        {
            if (string.IsNullOrWhiteSpace(code) || _autoTradeController == null)
                return;

            var holding = FindHolding(code);

            _autoTradeController.UpdatePosition(
                code,
                holding == null ? 0 : holding.Quantity,
                holding == null ? 0 : holding.EntryPrice);
        }

        private HoldingInfo FindHolding(string code)
        {
            if (string.IsNullOrWhiteSpace(code) || AccountHoldings == null)
                return null;

            return AccountHoldings.FirstOrDefault(x => x != null && x.Code == code);
        }

        private IEnumerable<OrderInfo> GetOpenOrdersForAutoTrade()
        {
            if (OrderHistory == null)
                return Enumerable.Empty<OrderInfo>();

            return OrderHistory
                .Where(x =>
                    x != null &&
                    !string.IsNullOrWhiteSpace(x.Code) &&
                    !string.IsNullOrWhiteSpace(x.OrderType))
                .Select(CloneOrderInfo)
                .ToList();
        }

        private void SyncAutoTradeMinuteCandles(string code, string reason = null)
        {
            try
            {
                if (_autoTradeController == null || string.IsNullOrWhiteSpace(code))
                    return;

                var minutes = GetMinuteCandlesForAutoTrade(code)
                    .Where(x => x != null)
                    .OrderBy(x => x.LastUpdated)
                    .Select(CloneTrackedSymbolForAutoTrade)
                    .ToList();

                if (minutes.Count == 0)
                    return;

                _autoTradeController.UpdateMinuteCandles(code, minutes);

                if (!string.IsNullOrWhiteSpace(reason))
                {
                    var last = minutes[minutes.Count - 1];

                    AddAutoTradeAnalysisLog(
                        $"[Core분봉동기화] {reason} / {code} / " +
                        $"분봉={minutes.Count} / 마지막={last.LastUpdated:HH:mm} / 종가={last.LastPrice:N0}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[AutoTradeCore 분봉 동기화 실패] " + ex.Message);
            }
        }

        private IEnumerable<TrackedSymbol> GetMinuteCandlesForAutoTrade(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return Enumerable.Empty<TrackedSymbol>();

            var holdingMinutes = GetHoldingStoreMinutes(code);
            if (holdingMinutes.Any())
                return holdingMinutes;

            return GetCurrentWindowMinutes(code);
        }

        private IEnumerable<TrackedSymbol> GetHoldingStoreMinutes(string code)
        {
            HoldingSymbolContext store;
            if (!GlobalHoldingStore.TryGet(code, out store) || store == null)
                return Enumerable.Empty<TrackedSymbol>();

            lock (store.SyncRoot)
            {
                if (store.MinuteList == null || store.MinuteList.Count == 0)
                    return Enumerable.Empty<TrackedSymbol>();

                return store.MinuteList
                    .Where(x =>
                        x != null &&
                        x.Code == code &&
                        x.LastUpdated != DateTime.MinValue &&
                        x.LastPrice > 0)
                    .OrderBy(x => x.LastUpdated)
                    .Select(CloneTrackedSymbolForAutoTrade)
                    .ToList();
            }
        }

        private IEnumerable<TrackedSymbol> GetCurrentWindowMinutes(string code)
        {
            if (Context == null || Context.Code != code)
                return Enumerable.Empty<TrackedSymbol>();

            lock (_syncLock)
            {
                if (_minuteHistoryBuffer == null || _minuteHistoryBuffer.Count == 0)
                    return Enumerable.Empty<TrackedSymbol>();

                return _minuteHistoryBuffer
                    .Where(x =>
                        x != null &&
                        x.Code == code &&
                        x.CandleTime != DateTime.MinValue &&
                        x.Close > 0)
                    .OrderBy(x => x.CandleTime)
                    .Select(ToTrackedSymbol)
                    .Select(CloneTrackedSymbolForAutoTrade)
                    .ToList();
            }
        }

        private int GetActiveAutoTradeSlotCount()
        {
            try
            {
                var app = Application.Current;
                if (app == null)
                    return 1;

                if (app.Dispatcher.CheckAccess())
                    return GetActiveAutoTradeSlotCountOnUiThread();

                return app.Dispatcher.Invoke(GetActiveAutoTradeSlotCountOnUiThread);
            }
            catch
            {
                return 1;
            }
        }

        private int GetActiveAutoTradeSlotCountOnUiThread()
        {
            int count = Application.Current.Windows
                .Cast<Window>()
                .Select(w => w.DataContext as MainWindowViewModel)
                .Where(vm =>
                    vm != null &&
                    vm._autoTradeSettings != null &&
                    vm._autoTradeSettings.Enabled &&
                    vm.Context != null &&
                    !string.IsNullOrWhiteSpace(vm.Context.Code))
                .Select(vm => vm.Context.Code)
                .Distinct()
                .Count();

            return Math.Max(1, count);
        }

        private void MarkAutoTradeDataReady(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return;

            _autoTradeReadyCode = code;
            _isAutoTradeDataReady = true;
        }

        private void MarkAutoTradeDataNotReady(string code = null)
        {
            _isAutoTradeDataReady = false;
            _autoTradeReadyCode = string.IsNullOrWhiteSpace(code) ? string.Empty : code;
        }

        private bool CanRunAutoTradeForTick(TrackedSymbol tick)
        {
            return tick != null &&
                   _autoTradeController != null &&
                   _autoTradeSettings != null &&
                   _autoTradeSettings.Enabled &&
                   Context != null &&
                   Context.Code == tick.Code &&
                   _isHistoryBindingComplete &&
                   _isAutoTradeDataReady &&
                   _autoTradeReadyCode == tick.Code;
        }

        private static TickFrame CloneTickFrame(TickFrame x)
        {
            if (x == null)
                return null;

            return new TickFrame
            {
                Code = x.Code,
                Time = x.Time,
                Open = x.Open,
                High = x.High,
                Low = x.Low,
                Close = x.Close,
                Volume = x.Volume,
                AccumulatedVolume = x.AccumulatedVolume,
                AvgStrength = x.AvgStrength,
                LastStrength = x.LastStrength,
                TotalAskQty = x.TotalAskQty,
                TotalBidQty = x.TotalBidQty,
                TickCount = x.TickCount,
                BuyTickCount = x.BuyTickCount,
                SellTickCount = x.SellTickCount,
                UpdatedAt = x.UpdatedAt
            };
        }

        private static TrackedSymbol CloneTrackedSymbolForAutoTrade(TrackedSymbol x)
        {
            if (x == null)
                return null;

            return new TrackedSymbol
            {
                Code = x.Code,
                LastPrice = x.LastPrice,
                LastVolume = x.LastVolume,
                ClosePrice = x.ClosePrice,
                HighPrice = x.HighPrice,
                LowPrice = x.LowPrice,
                AccumulatedVolume = x.AccumulatedVolume,
                TotalAskQty = x.TotalAskQty,
                TotalBidQty = x.TotalBidQty,
                Strength = x.Strength,
                Side = x.Side,
                LastUpdated = x.LastUpdated
            };
        }
    }
}
