﻿using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        // Stage6 리팩토링: 이 파일의 활성 로직은 다른 AutoTrading partial 파일로 통합됨.
        // 기존 csproj의 Compile Include 호환을 위해 파일은 유지한다.
    }
}
