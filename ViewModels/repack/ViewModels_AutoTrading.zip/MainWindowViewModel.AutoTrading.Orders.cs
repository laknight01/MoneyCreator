﻿using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void OnAutoTradeOrderRequested(OrderRequest request)
        {
            if (request == null || request.Signal == null)
                return;

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Send,
                new Action(() =>
                {
                    ExecuteAutoTradeOrderRequest(request);
                }));
        }

        private void ExecuteAutoTradeOrderRequest(OrderRequest request)
        {
            try
            {
                var signal = request?.Signal;
                if (signal == null)
                    return;

                string code = signal.Code;
                int quantity = signal.Quantity;
                int price = signal.Price <= 0 ? 0 : (int)Math.Round(signal.Price);

                if (string.IsNullOrWhiteSpace(code) || quantity <= 0)
                {
                    _autoTradeController?.MarkOrderSubmitted(request, -1);
                    return;
                }

                string actionName = signal.Action == TradeActionType.Buy
                    ? "자동매수"
                    : "자동매도";

                if (request.DryRun)
                {
                    AddAutoTradeAnalysisLog(
                        $"[DRY주문] {actionName} {code} {quantity}주 / {price:N0}원 / {signal.StrategyName} / {signal.Reason}");

                    _autoTradeController?.MarkOrderCompleted(request);
                    return;
                }

                int sendResult = SendAutoTradeOrder(request, code, quantity, price);

                _autoTradeController?.MarkOrderSubmitted(request, sendResult);

                LogAutoTradeOrderResult(sendResult, actionName, code, quantity, price, signal);

                if (sendResult == 0)
                    RequestAutoTradeOrderSync(request);
            }
            catch (Exception ex)
            {
                _autoTradeController?.MarkOrderSubmitted(request, -1);
                Debug.WriteLine("[자동매매 주문 처리 오류] " + ex.Message);
                AddAutoTradeAnalysisLog("[자동매매 주문 처리 오류] " + ex.Message);
            }
        }

        private int SendAutoTradeOrder(OrderRequest request, string code, int quantity, int price)
        {
            return _marketApi.SendOrder(
                request.WindowId,
                request.ScreenNo,
                request.AccountNo,
                request.OrderType,
                code,
                quantity,
                price,
                request.HogaType);
        }

        private void LogAutoTradeOrderResult(
            int sendResult,
            string actionName,
            string code,
            int quantity,
            int price,
            TradeSignal signal)
        {
            AddAutoTradeAnalysisLog(
                sendResult == 0
                    ? $"[자동주문접수] {actionName} {code} {quantity}주 / {price:N0}원 / {signal.StrategyName}"
                    : $"[자동주문실패] {actionName} {code} {quantity}주 / result={sendResult}");
        }

        private void RequestAutoTradeOrderSync(OrderRequest request)
        {
            if (string.IsNullOrWhiteSpace(SelectedAccount))
                return;

            _marketApi.RequestOrderHistory("COMMON", SelectedAccount, ScreenNo);
            _marketApi.RequestUnfilledOrders("COMMON", SelectedAccount, ScreenNo);

            ScheduleAutoTradeCancelIfUnfilled(request);
        }

        private void ScheduleAutoTradeCancelIfUnfilled(OrderRequest request)
        {
            if (request == null || request.Signal == null)
                return;

            string code = request.Signal.Code;
            string key = $"{code}_{request.Signal.Action}_{DateTime.Now:yyyyMMddHHmmssfff}";

            if (!_autoCancelWatchMap.TryAdd(key, true))
                return;

            Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(3000);

                    if (string.IsNullOrWhiteSpace(SelectedAccount))
                        return;

                    string orderNo;
                    int untradedQty;

                    if (!await TryFindCancelableAutoTradeOrder(request, out orderNo, out untradedQty))
                    {
                        AddAutoTradeAnalysisLog(
                            $"[자동취소 생략] {code} / 취소 가능 원주문번호 없음 또는 미체결 없음");
                        return;
                    }

                    int cancelType = GetCancelOrderType(request.Signal.Action);
                    if (cancelType <= 0)
                        return;

                    RequestAutoTradeCancelOrder(request, orderNo, untradedQty, cancelType);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("[자동취소 처리 오류] " + ex.Message);
                    AddAutoTradeAnalysisLog("[자동취소 처리 오류] " + ex.Message);
                }
                finally
                {
                    bool removed;
                    _autoCancelWatchMap.TryRemove(key, out removed);
                }
            });
        }

        private async Task<bool> TryFindCancelableAutoTradeOrder(
            OrderRequest request,
            out string orderNo,
            out int untradedQty)
        {
            orderNo = null;
            untradedQty = 0;

            for (int i = 0; i < 3; i++)
            {
                _marketApi.RequestUnfilledOrders("COMMON", SelectedAccount, ScreenNo);

                await Task.Delay(i == 0 ? 700 : 1000);

                if (_autoTradeController != null &&
                    _autoTradeController.TryGetCancelableOrder(request, out orderNo, out untradedQty))
                {
                    return !string.IsNullOrWhiteSpace(orderNo) && untradedQty > 0;
                }
            }

            return false;
        }

        private static int GetCancelOrderType(TradeActionType action)
        {
            if (action == TradeActionType.Buy)
                return 3;

            if (action == TradeActionType.Sell)
                return 4;

            return 0;
        }

        private void RequestAutoTradeCancelOrder(
            OrderRequest request,
            string orderNo,
            int untradedQty,
            int cancelType)
        {
            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Send,
                new Action(() =>
                {
                    int result = _marketApi.SendOrder(
                        WindowId,
                        ScreenNo,
                        SelectedAccount,
                        cancelType,
                        request.Signal.Code,
                        untradedQty,
                        0,
                        "00",
                        orderNo);

                    if (result == 0)
                    {
                        _autoTradeController?.MarkCancelRequested(request);

                        AddAutoTradeAnalysisLog(
                            $"[자동취소] {request.Signal.Code} / 미체결 {untradedQty}주 / 원주문={orderNo}");

                        _marketApi.RequestOrderHistory("COMMON", SelectedAccount, ScreenNo);
                        _marketApi.RequestUnfilledOrders("COMMON", SelectedAccount, ScreenNo);
                    }
                    else
                    {
                        AddAutoTradeAnalysisLog(
                            $"[자동취소 실패] {request.Signal.Code} / result={result} / 원주문={orderNo}");
                    }
                }));
        }
    }
}
