﻿using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;
using MoneyCreator.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void OnAutoTradeAnalysisEvaluated(FeatureSnapshot feature, TradeSignal signal)
        {
            if (feature == null)
                return;

            PersistAutoTradeAnalysis(feature, signal);

            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    UpdateTradeAnalysisCardFromFeature(feature, signal);
                }));
        }

        private void PersistAutoTradeAnalysis(FeatureSnapshot feature, TradeSignal signal)
        {
            try
            {
                if (feature == null || string.IsNullOrWhiteSpace(feature.Code) || Db == null)
                    return;

                DateTime snapshotTime = feature.Time == default(DateTime)
                    ? DateTime.Now
                    : feature.Time;

                SaveFeatureSnapshotIfNeeded(feature, signal, snapshotTime);
                SaveSignalLogIfNeeded(feature, signal, snapshotTime);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[자동매매 분석 저장 실패] " + ex.Message);
            }
        }

        private void SaveFeatureSnapshotIfNeeded(
            FeatureSnapshot feature,
            TradeSignal signal,
            DateTime snapshotTime)
        {
            if (_autoTradeSettings == null || !_autoTradeSettings.EnableMlDataCollection)
                return;

            int intervalSeconds = Math.Max(1, _autoTradeSettings.FeatureSnapshotIntervalSeconds);

            DateTime lastSaved;
            bool shouldSave =
                !_lastFeatureSnapshotSavedAtByCode.TryGetValue(feature.Code, out lastSaved) ||
                (snapshotTime - lastSaved).TotalSeconds >= intervalSeconds;

            if (!shouldSave)
                return;

            _lastFeatureSnapshotSavedAtByCode[feature.Code] = snapshotTime;

            Db.EnqueueFeatureSnapshot(CreateFeatureSnapshotRecord(feature, signal, snapshotTime));
        }

        private FeatureSnapshotRecord CreateFeatureSnapshotRecord(
            FeatureSnapshot feature,
            TradeSignal signal,
            DateTime snapshotTime)
        {
            return new FeatureSnapshotRecord
            {
                SnapshotId = feature.SnapshotId,
                Code = feature.Code,
                SnapshotTime = snapshotTime,
                Price = feature.Price,
                PriceChangeRate = feature.PriceChangeRate1m,
                Strength = feature.Strength,
                StrengthDelta = feature.StrengthDelta,
                VolumeAccel = feature.VolumeAccel,
                BidAskRatio = feature.BidAskRatio,
                BuyPressureScore = feature.BuyPressureScore,
                SecondTrend = feature.TradeMode.ToString(),
                MinuteTrend = feature.Phase.ToString(),
                HourTrend = feature.MarketTrend.ToString(),
                Phase = feature.Phase.ToString(),
                IsSideways = feature.IsSideways,
                TrendStrength = feature.TrendStrength,
                VolatilityRate = feature.VolatilityRate,
                RangePosition = feature.RangePosition,
                TickCount5Min = feature.RawTickCount30s,
                SecondCandleCount = feature.TickFrameCount5m,
                MinuteCandleCount = feature.MinuteCandleCount2d,
                SignalAction = signal == null ? "HOLD" : signal.Action.ToString(),
                SignalScore = signal == null ? 0 : signal.Score,
                StrategyName = signal == null ? "HOLD" : signal.StrategyName,
                TradeMode = feature.TradeMode.ToString(),
                CreatedAt = DateTime.Now
            };
        }

        private void SaveSignalLogIfNeeded(
            FeatureSnapshot feature,
            TradeSignal signal,
            DateTime signalTime)
        {
            if (!ShouldSaveSignalLog(signal))
                return;

            Db.EnqueueSignalLog(CreateSignalLogRecord(feature, signal, signalTime));
        }

        private bool ShouldSaveSignalLog(TradeSignal signal)
        {
            if (signal == null)
                return false;

            if (signal.Action != TradeActionType.Hold)
                return true;

            return _autoTradeSettings != null &&
                   _autoTradeSettings.AnalysisLogMode == AutoTradeAnalysisLogMode.All;
        }

        private SignalLogRecord CreateSignalLogRecord(
            FeatureSnapshot feature,
            TradeSignal signal,
            DateTime signalTime)
        {
            return new SignalLogRecord
            {
                SignalId = Guid.NewGuid().ToString("N"),
                Code = feature.Code,
                SignalTime = signalTime,
                Action = signal.Action.ToString(),
                Score = signal.Score,
                StrategyName = signal.StrategyName,
                Reason = signal.Reason,
                AiUsed = _autoTradeSettings != null && _autoTradeSettings.UseAi,
                AiApproved = false,
                AiReason = null,
                MlUsed = _autoTradeSettings != null && _autoTradeSettings.UseMlNet,
                MlApproved = !string.IsNullOrWhiteSpace(signal.TiRexDirection),
                MlScore = signal.TiRexConfidence,
                SnapshotId = feature.SnapshotId,
                TradeMode = feature.TradeMode.ToString(),
                TiRexDirection = signal.TiRexDirection,
                TiRexConfidence = signal.TiRexConfidence,
                TiRexPredictedReturn = signal.TiRexPredictedReturn,
                CreatedAt = DateTime.Now
            };
        }

        private void UpdateTradeAnalysisCardFromFeature(FeatureSnapshot feature, TradeSignal signal)
        {
            if (feature == null)
                return;

            string action = signal == null ? "HOLD" : signal.Action.ToString();
            string profitRate = feature.ProfitRate.ToString("F2") + "%";

            TradeCardUpdatedAt = DateTime.Now.ToString("HH:mm:ss");
            TradeCardCode = string.IsNullOrWhiteSpace(feature.Code) ? "-" : feature.Code;
            TradeCardTitle = GetTradeCardTitle(feature);
            TradeCardAction = action;
            TradeCardScore = signal == null ? "0" : signal.Score.ToString();
            TradeCardPrice = feature.Price <= 0 ? "-" : feature.Price.ToString("N0");
            TradeCardHoldingQty = feature.HoldingQty.ToString();
            TradeCardProfitRate = profitRate;
            TradeCardOneMinuteChange = feature.PriceChangeRate1m.ToString("F2") + "%";
            TradeCardThreeMinuteChange = feature.PriceChangeRate3m.ToString("F2") + "%";
            TradeCardStrength = feature.Strength.ToString("F1");
            TradeCardVolumeRatio = feature.VolumeRatio.ToString("F2");
            TradeCardBidAskRatio = feature.BidAskRatio.ToString("F2");
            TradeCardPhase = feature.MarketTrend.ToString();
            TradeCardMarketPhase = feature.Phase.ToString();
            TradeCardTradeMode = feature.TradeMode.ToString();
            TradeCardStrategy = string.IsNullOrWhiteSpace(signal?.StrategyName) ? "-" : signal.StrategyName;
            TradeCardReason = ResolveTradeCardReason(feature, signal);

            ApplyTradeCardBrushes(action, profitRate);
        }

        private string GetTradeCardTitle(FeatureSnapshot feature)
        {
            if (Context != null &&
                Context.Code == feature.Code &&
                !string.IsNullOrWhiteSpace(Context.Name))
            {
                return Context.Name;
            }

            return string.IsNullOrWhiteSpace(feature.Code) ? "-" : feature.Code;
        }

        private static string ResolveTradeCardReason(FeatureSnapshot feature, TradeSignal signal)
        {
            if (!string.IsNullOrWhiteSpace(signal?.Reason))
                return signal.Reason;

            if (!string.IsNullOrWhiteSpace(feature?.HoldReason))
                return feature.HoldReason;

            return "분석 완료";
        }
    }
}
