﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        public ICommand OrderCommand => new RelayCommand<string>(async (type) =>
        {
            if (string.IsNullOrWhiteSpace(SelectedAccount))
            {
                AddLog("⚠️ 계좌를 먼저 선택해줘.");
                return;
            }

            if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
            {
                AddLog("⛔ 주문 실패: 종목코드 없음");
                return;
            }

            if (Quantity <= 0 || OrderPrice <= 0)
            {
                AddLog($"⛔ 주문 실패: 수량/가격 오류 / Qty={Quantity}, Price={OrderPrice}");
                return;
            }

            string action = GetOrderActionName(type);
            int orderTypeCode = type == "BUY" ? 1 : 2;

            string msg =
                $"[{action}] {Context.Name}\n" +
                $"가격 : {OrderPrice:#,0}원\n" +
                $"수량 : {Quantity:#,0}주\n" +
                $"총액 : {TotalAmount:#,0}원\n" +
                $"진행할까?";

            if (!await PopBox.Show(HostWindow, PopUpType.Confirm, msg))
                return;

            int result = _marketApi.SendOrder(
                WindowId,
                ScreenNo,
                SelectedAccount,
                orderTypeCode,
                Context.Code,
                Quantity,
                (int)OrderPrice,
                "00");

            if (result == 0)
            {
                AddLog($"🚀 {action} 주문 전송 성공: {Context.Name} {Quantity}주");

                await PopBox.Show(
                    HostWindow,
                    PopUpType.Alert,
                    $"[주문전송완료]\n{Context.Name}: {OrderPrice:#,0}원 / {Quantity:#,0}주\n키움 응답 기준으로 주문내역을 갱신합니다.");

                RequestOrderStateRefresh("COMMON");
            }
            else
            {
                AddLog($"❌ {action} 주문 전송 실패: {Context.Name} / result={result}");
            }
        });

        public ICommand SetCurrentPriceCommand => new RelayCommand(() =>
        {
            if (Context != null && Context.LastPrice > 0)
            {
                OrderPrice = Context.LastPrice;
            }
            else
            {
                AddLog("⚠️ 현재가 데이터가 없습니다. 종목을 다시 선택해주세요.");
            }
        });

        public ICommand CancelOrderCommand => new RelayCommand<OrderInfo>(async (order) =>
        {
            if (!ValidateOrderTarget(order, "취소"))
                return;

            int cancelOrderType = GetCancelOrderType(order);
            if (cancelOrderType == 0)
            {
                AddLog($"⛔ 취소 실패: 주문구분 확인 불가 / {order.OrderType}");
                return;
            }

            int cancelQty = GetRemainingOrderQty(order);
            if (cancelQty <= 0)
            {
                AddLog($"⛔ 취소 실패: 취소 가능 수량 없음 / {order.Name}");
                return;
            }

            int result = _marketApi.SendOrder(
                WindowId,
                ScreenNo,
                SelectedAccount,
                cancelOrderType,
                order.Code,
                cancelQty,
                0,
                "00",
                order.OrderNo);

            if (result == 0)
            {
                AddLog($"✅ 취소 요청 전송 성공: {order.Name} / {cancelQty}주 / 원주문={order.OrderNo}");
                RequestOrderStateRefresh("COMMON");
            }
            else
            {
                AddLog($"❌ 취소 요청 실패: {order.Name} / result={result}");
            }
        });

        public ICommand ModifyOrderCommand => new RelayCommand<OrderInfo>(async (order) =>
        {
            if (!ValidateOrderTarget(order, "정정"))
                return;

            int modifyCode = GetModifyOrderType(order);
            if (modifyCode == 0)
            {
                AddLog($"⛔ 정정 실패: 주문구분 확인 불가 / {order.OrderType}");
                return;
            }

            var modifyResult = await OrderView.ShowModify(HostWindow, order);
            if (!modifyResult.IsConfirmed)
                return;

            if (modifyResult.NewQty <= 0 || modifyResult.NewPrice <= 0)
            {
                AddLog($"⛔ 정정 실패: 수량/가격 오류 / Qty={modifyResult.NewQty}, Price={modifyResult.NewPrice}");
                return;
            }

            int sendResult = _marketApi.SendOrder(
                WindowId,
                ScreenNo,
                SelectedAccount,
                modifyCode,
                order.Code,
                modifyResult.NewQty,
                modifyResult.NewPrice,
                "00",
                order.OrderNo);

            if (sendResult == 0)
            {
                AddLog($"✅ 정정 요청 전송 성공: {order.Name} / {modifyResult.NewPrice:#,0}원 / {modifyResult.NewQty}주");

                await PopBox.Show(
                    HostWindow,
                    PopUpType.Alert,
                    $"[정정전송완료]\n{order.Name}: {modifyResult.NewPrice:#,0}원 / {modifyResult.NewQty:#,0}주\n키움 응답 기준으로 주문내역을 갱신합니다.");

                RequestOrderStateRefresh("COMMON");
            }
            else
            {
                AddLog($"❌ 정정 요청 실패: {order.Name} / result={sendResult}");
            }
        });

        public ICommand AdjustPriceCommand => new RelayCommand<string>((param) =>
        {
            if (Price <= 0)
                return;

            double tickSize = GetTickSize(Price);
            int direction = int.Parse(param);

            OrderPrice += tickSize * direction;
        });
    }
}
