﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private string GetOrderActionName(string type)
        {
            switch (type)
            {
                case "BUY":
                    return "매수";
                case "SELL":
                    return "매도";
                case "BUY_CANCEL":
                    return "매수취소";
                case "SELL_CANCEL":
                    return "매도취소";
                case "BUY_MODIFY":
                    return "매수정정";
                case "SELL_MODIFY":
                    return "매도정정";
                default:
                    return type ?? "-";
            }
        }

        private string GetOrderTypeDisplayName(string orderType)
        {
            if (string.IsNullOrWhiteSpace(orderType))
                return "체결";

            if (orderType.Contains("매수") && orderType.Contains("취소"))
                return "매수취소";

            if (orderType.Contains("매도") && orderType.Contains("취소"))
                return "매도취소";

            if (orderType.Contains("매수") && orderType.Contains("정정"))
                return "매수정정";

            if (orderType.Contains("매도") && orderType.Contains("정정"))
                return "매도정정";

            if (orderType.Contains("매수"))
                return "매수체결";

            if (orderType.Contains("매도"))
                return "매도체결";

            return orderType;
        }

        private double GetTickSize(double currentPrice)
        {
            if (currentPrice < 2000) return 1;
            if (currentPrice < 5000) return 5;
            if (currentPrice < 20000) return 10;
            if (currentPrice < 50000) return 50;
            if (currentPrice < 200000) return 100;
            return 500;
        }

        private void RequestOrderStateRefresh(string windowId = "COMMON")
        {
            if (string.IsNullOrWhiteSpace(SelectedAccount))
                return;

            _marketApi.RequestOrderHistory(windowId, SelectedAccount, ScreenNo);
            _marketApi.RequestUnfilledOrders(windowId, SelectedAccount, ScreenNo);
        }

        private bool IsBuyOrder(OrderInfo order)
        {
            return order != null &&
                   !string.IsNullOrWhiteSpace(order.OrderType) &&
                   order.OrderType.Contains("매수");
        }

        private bool IsSellOrder(OrderInfo order)
        {
            return order != null &&
                   !string.IsNullOrWhiteSpace(order.OrderType) &&
                   order.OrderType.Contains("매도");
        }

        private bool IsSellFilledOrder(OrderInfo order)
        {
            return order != null &&
                   order.ExecQty > 0 &&
                   IsSellOrder(order) &&
                   !string.IsNullOrWhiteSpace(order.TradeGroupId);
        }

        private int GetCancelOrderType(OrderInfo order)
        {
            if (IsBuyOrder(order))
                return 3;

            if (IsSellOrder(order))
                return 4;

            return 0;
        }

        private int GetModifyOrderType(OrderInfo order)
        {
            if (IsBuyOrder(order))
                return 5;

            if (IsSellOrder(order))
                return 6;

            return 0;
        }

        private int GetRemainingOrderQty(OrderInfo order)
        {
            if (order == null)
                return 0;

            if (order.UntradedQty > 0)
                return order.UntradedQty;

            int remainingQty = order.Qty - order.ExecQty;
            return remainingQty > 0 ? remainingQty : 0;
        }

        private bool ValidateOrderTarget(OrderInfo order, string actionName)
        {
            if (order == null)
                return false;

            if (string.IsNullOrWhiteSpace(SelectedAccount))
            {
                AddLog($"⛔ {actionName} 실패: 계좌번호 없음");
                return false;
            }

            if (string.IsNullOrWhiteSpace(order.OrderNo))
            {
                AddLog($"⛔ {actionName} 실패: 원주문번호 없음 / {order.Code}");
                return false;
            }

            if (string.IsNullOrWhiteSpace(order.Code))
            {
                AddLog($"⛔ {actionName} 실패: 종목코드 없음");
                return false;
            }

            return true;
        }

        private static OrderInfo CloneOrderInfo(OrderInfo x)
        {
            if (x == null)
                return null;

            return new OrderInfo
            {
                OrderNo = x.OrderNo,
                TradeGroupId = x.TradeGroupId,
                OrderTime = x.OrderTime,
                Code = x.Code,
                Name = x.Name,
                OrderType = x.OrderType,
                Qty = x.Qty,
                ExecQty = x.ExecQty,
                UntradedQty = x.UntradedQty,
                Price = x.Price,
                ExecPrice = x.ExecPrice,
                Status = x.Status,
                OrderStatus = x.OrderStatus,
                StrategyName = x.StrategyName,
                Fee = x.Fee,
                Tax = x.Tax,
                ParentOrderNo = x.ParentOrderNo,
                TiRexDirection = x.TiRexDirection,
                TiRexConfidence = x.TiRexConfidence,
                TiRexPredictedReturn = x.TiRexPredictedReturn
            };
        }

        private string NormalizeOrderTime(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
                return DateTime.Now.ToString("yyyyMMddHHmmss");

            raw = raw.Trim();

            DateTime dt;

            if (DateTime.TryParseExact(raw, "yyyyMMddHHmmss", null,
                System.Globalization.DateTimeStyles.None, out dt))
                return raw;

            if (DateTime.TryParseExact(raw, "HH:mm:ss", null,
                System.Globalization.DateTimeStyles.None, out dt))
                return DateTime.Today.Add(dt.TimeOfDay).ToString("yyyyMMddHHmmss");

            if (DateTime.TryParseExact(raw, "HHmmss", null,
                System.Globalization.DateTimeStyles.None, out dt))
                return DateTime.Today.Add(dt.TimeOfDay).ToString("yyyyMMddHHmmss");

            if (DateTime.TryParse(raw, out dt))
                return dt.ToString("yyyyMMddHHmmss");

            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        private DateTime ParseOrderDateTime(string orderTime, DateTime baseDate)
        {
            if (string.IsNullOrWhiteSpace(orderTime))
                return baseDate;

            DateTime dt;

            if (DateTime.TryParseExact(
                orderTime,
                "yyyyMMddHHmmss",
                null,
                System.Globalization.DateTimeStyles.None,
                out dt))
            {
                return dt;
            }

            if (DateTime.TryParseExact(
                orderTime,
                "HH:mm:ss",
                null,
                System.Globalization.DateTimeStyles.None,
                out dt))
            {
                return baseDate.Date.Add(dt.TimeOfDay);
            }

            if (DateTime.TryParse(orderTime, out dt))
                return dt;

            return baseDate;
        }

        private DateTime ParseOrderTime(string orderTime)
        {
            return ParseOrderDateTime(orderTime, GetCurrentChartDate());
        }

        private OrderStatus ParseOrderStatus(
            string status,
            string orderType,
            int execQty,
            int untradedQty)
        {
            status = status?.Trim() ?? string.Empty;
            orderType = orderType?.Trim() ?? string.Empty;

            if (orderType.Contains("취소"))
                return OrderStatus.Cancelled;

            if (orderType.Contains("정정") && status == "확인")
                return OrderStatus.Corrected;

            if (execQty > 0 && untradedQty > 0)
                return OrderStatus.PartiallyFilled;

            if (execQty > 0 && untradedQty <= 0)
                return OrderStatus.FullyFilled;

            if (untradedQty > 0)
            {
                if (status == "접수")
                    return OrderStatus.Received;

                return OrderStatus.Confirmed;
            }

            return status switch
            {
                "접수" => OrderStatus.Received,
                "확인" => OrderStatus.Confirmed,
                "체결" => OrderStatus.FullyFilled,
                "부분체결" => OrderStatus.PartiallyFilled,
                "정정" => OrderStatus.Corrected,
                "취소" => OrderStatus.Cancelled,
                "거부" => OrderStatus.Rejected,
                _ => OrderStatus.None
            };
        }
    }
}
