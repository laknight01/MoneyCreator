﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private async void Kiwoom_OnGlobalUpdateRequired(string accNo)
        {
            if (SelectedAccount != accNo)
                return;

            await Task.Delay(300);
            RequestOrderStateRefresh(WindowId);
        }

        private async void Kiwoom_OnOrderFilled(string windowId, string code, string name, string orderType, int filledQty, double filledPrice)
        {
            if (!IsOrderEventForCurrentWindow(windowId))
                return;

            string actionName = GetOrderTypeDisplayName(orderType);

            string msg =
                $"[{name}] {actionName}\n" +
                $"종목코드 : {code}\n" +
                $"구분 : {actionName}\n" +
                $"체결가격 : {filledPrice:#,0}원\n" +
                $"체결수량 : {filledQty:#,0}주\n" +
                $"체결금액 : {(filledPrice * filledQty):#,0}원\n" +
                $"처리되었습니다.";

            await PopBox.Show(HostWindow, PopUpType.Alert, msg);

            if (!string.IsNullOrWhiteSpace(SelectedAccount))
            {
                _marketApi.RequestCashInfo(WindowId, SelectedAccount, ScreenNo);
                _marketApi.RequestAccountHoldings(WindowId, SelectedAccount, ScreenNo);
                RequestOrderStateRefresh("COMMON");
            }

            RefreshOrderHistory();
            SyncAutoTradeState("주문 체결 갱신");
        }

        private void Kiwoom_OnOrdersReceived(string windowId, List<OrderInfo> orders)
        {
            if (!IsOrderEventForCurrentWindow(windowId))
                return;

            var safeOrders = PrepareIncomingOrders(orders, "KIWOOM");
            if (safeOrders.Count == 0)
                return;

            ApplyOrdersToUi(safeOrders, completeInitialLoadingToken: true, syncReason: "키움 주문내역 갱신");
            SaveOrdersAndBuildTradeResults(safeOrders, buildTradeResultOnSell: true, logTitle: "주문내역");
        }

        private void Kiwoom_OnUnfilledOrdersReceived(string windowId, List<OrderInfo> orders)
        {
            if (!IsOrderEventForCurrentWindow(windowId))
                return;

            var safeOrders = PrepareIncomingOrders(orders, "UNFILLED");

            ApplyOrdersToUi(safeOrders, completeInitialLoadingToken: false, syncReason: "키움 미체결 갱신");
            SaveOrdersAndBuildTradeResults(safeOrders, buildTradeResultOnSell: false, logTitle: "미체결 주문");
        }

        private bool IsOrderEventForCurrentWindow(string windowId)
        {
            return windowId == WindowId || windowId == "COMMON";
        }

        private List<OrderInfo> PrepareIncomingOrders(List<OrderInfo> orders, string fallbackStrategyName)
        {
            if (orders == null || orders.Count == 0)
                return new List<OrderInfo>();

            var result = new List<OrderInfo>();

            foreach (var source in orders)
            {
                if (source == null || string.IsNullOrWhiteSpace(source.Code))
                    continue;

                var order = CloneOrderInfo(source);
                NormalizeIncomingOrder(order, fallbackStrategyName);
                result.Add(order);
            }

            return result;
        }

        private void NormalizeIncomingOrder(OrderInfo order, string fallbackStrategyName)
        {
            if (order == null)
                return;

            order.OrderTime = NormalizeOrderTime(order.OrderTime);

            order.OrderStatus = ParseOrderStatus(
                order.Status,
                order.OrderType,
                order.ExecQty,
                order.UntradedQty);

            if (string.IsNullOrWhiteSpace(order.TradeGroupId) && Db != null)
                order.TradeGroupId = Db.GetTradeGroupId(order.Code);

            if (string.IsNullOrWhiteSpace(order.StrategyName))
                order.StrategyName = fallbackStrategyName;
        }

        private void ApplyOrdersToUi(List<OrderInfo> orders, bool completeInitialLoadingToken, string syncReason)
        {
            Application.Current?.Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (orders != null)
                    {
                        foreach (var order in orders)
                        {
                            AddOrUpdateOrderHistory(order);

                            if (order.ExecQty > 0 && order.ExecPrice > 0)
                                AddTradeMarkerIfNeeded(order);
                        }
                    }

                    RefreshOrderHistory();

                    if (completeInitialLoadingToken)
                        CompleteInitialMainLoadingToken("ORDERS");

                    UpdateAutoTradeCash(syncReason);
                    SyncAutoTradeState(syncReason);
                }));
        }

        private void SaveOrdersAndBuildTradeResults(List<OrderInfo> orders, bool buildTradeResultOnSell, string logTitle)
        {
            if (orders == null || orders.Count == 0 || Db == null)
                return;

            Task.Run(() =>
            {
                try
                {
                    foreach (var order in orders)
                    {
                        try
                        {
                            Db.InsertOrder(order);

                            if (buildTradeResultOnSell && IsSellFilledOrder(order))
                                Db.BuildTradeResultFromOrders(order.TradeGroupId);
                        }
                        catch (Exception ex)
                        {
                            AddLog($"❌ {logTitle}/성과 저장 실패: {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[{logTitle} 저장 실패] " + ex.Message);
                    AddLog($"❌ {logTitle} 저장 실패: {ex.Message}");
                }
            });
        }
    }
}
