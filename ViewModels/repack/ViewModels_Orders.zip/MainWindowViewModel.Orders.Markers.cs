﻿using AxKHOpenAPILib;
using MoneyCreator.Biz;
using MoneyCreator.Models;
using MoneyCreator.Service;
using MoneyCreator.View;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using MoneyCreator.AutoTrading;
using MoneyCreator.DataBase;

namespace MoneyCreator.ViewModels
{
    public partial class MainWindowViewModel
    {
        private void AddTradeMarkerIfNeeded(OrderInfo order)
        {
            if (order == null)
                return;

            if (order.ExecQty <= 0 || order.ExecPrice <= 0)
                return;

            if (string.IsNullOrWhiteSpace(order.Code))
                return;

            if (Context == null || order.Code != Context.Code)
                return;

            DateTime time;

            if (!DateTime.TryParse(order.OrderTime, out time))
                time = DateTime.Now;

            bool isBuy = order.OrderType != null && order.OrderType.Contains("매수");
            bool isSell = order.OrderType != null && order.OrderType.Contains("매도");

            if (!isBuy && !isSell)
                return;

            string key = $"{order.OrderNo}_{order.ExecQty}_{order.ExecPrice}_{isBuy}";

            if (_tradeMarkerKeys.Contains(key))
                return;

            _tradeMarkerKeys.Add(key);

            TradeMarkerRequested?.Invoke(time, order.ExecPrice, isBuy);
        }
        

        private ChartPayload CreateChartPayload(List<TrackedSymbol> candles, bool isFullRefresh)
        {
            return new ChartPayload
            {
                Candles = candles ?? new List<TrackedSymbol>(),
                Markers = GetCurrentTradeMarkers(),
                IsFullRefresh = isFullRefresh
            };
        }
        

        private List<TradeMarkerInfo> GetMarkersForChartRange(List<TrackedSymbol> candles)
        {
            // 차트는 실시간 때 마지막 분봉 1개만 받을 수 있다.
            // 따라서 마커를 candle 범위로 자르면 기존 매수/매도 점이 사라진다.
            // 현재 차트 날짜 기준 전체 주문 마커를 함께 넘긴다.
            return GetCurrentTradeMarkers();
        }
        

        public List<TradeMarkerInfo> GetCurrentTradeMarkers()
        {
            if (Context == null || string.IsNullOrWhiteSpace(Context.Code))
                return new List<TradeMarkerInfo>();

            DateTime chartDate = GetCurrentChartDate();

            var source = OrderHistory
                .Where(x =>
                    x != null &&
                    x.Code == Context.Code &&
                    x.ExecQty > 0 &&
                    ParseOrderDateTime(x.OrderTime, chartDate).Date == chartDate.Date)
                .GroupBy(x => string.IsNullOrWhiteSpace(x.OrderNo)
                    ? $"{x.Code}_{x.OrderTime}_{x.ExecPrice}_{x.Price}_{x.OrderType}"
                    : x.OrderNo)
                .Select(g => g.Last())
                .ToList();

            if (source.Count == 0)
            {
                try
                {
                    source = Db.LoadOrdersForChartMarkers(Context.Code, chartDate);
                }
                catch (Exception ex)
                {
                    AddLog($"❌ DB 매매마커 조회 실패: {ex.Message}");
                    source = new List<OrderInfo>();
                }
            }

            return source
                .Where(x => x != null && x.ExecQty > 0)
                .Select(x => new TradeMarkerInfo
                {
                    Time = ParseOrderDateTime(x.OrderTime, chartDate),
                    Price = x.ExecPrice > 0 ? x.ExecPrice : x.Price,
                    IsBuy = x.OrderType != null && x.OrderType.Contains("매수")
                })
                .Where(x => x.Price > 0)
                .OrderBy(x => x.Time)
                .ToList();
        }
        

        private DateTime GetCurrentChartDate()
        {
            if (Context.SymbolList != null && Context.SymbolList.Count > 0)
                return Context.SymbolList[Context.SymbolList.Count - 1].LastUpdated.Date;

            return DateTime.Today;
        }
        

        private void TryAddTradeMarkerFromOrder(OrderInfo order)
        {
            if (order == null)
                return;

            if (string.IsNullOrWhiteSpace(Context.Code) || order.Code != Context.Code)
                return;

            if (order.ExecQty <= 0)
                return;

            double markerPrice = order.ExecPrice > 0 ? order.ExecPrice : order.Price;

            if (markerPrice <= 0)
                return;

            // 여기서 차트 전체 재바인딩 금지.
            // 실시간 분봉 갱신 때 CreateChartPayload()에서 Markers가 같이 넘어간다.
        }
        
    }
}
